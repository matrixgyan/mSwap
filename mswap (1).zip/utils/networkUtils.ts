import { toast } from "sonner"

export const addNativeToken = (network) => {
  const existingTokens = JSON.parse(localStorage.getItem("managedTokens") || "[]")

  const newToken = {
    id: network.symbol,
    name: network.name,
    symbol: network.symbol,
    enabled: true,
    logo: network.icon || "/placeholder.svg",
    network: network.networkType,
    balance: "0",
    price: "$0",
    change: 0,
    balanceUsd: "$0",
  }

  const tokenExists = existingTokens.some((token) => token.symbol === network.symbol)

  if (!tokenExists) {
    const updatedTokens = [...existingTokens, newToken]
    localStorage.setItem("managedTokens", JSON.stringify(updatedTokens))
    toast.success(`${network.name} (${network.symbol}) has been added to your tokens`)
  }

  // Trigger storage event for cross-component communication
  window.dispatchEvent(
    new StorageEvent("storage", {
      key: "selectedNetwork",
      newValue: JSON.stringify(network),
    }),
  )
}

