import axios from "axios"
import * as web3 from "@solana/web3.js"
import { ethers } from "ethers"
import TronWeb from "tronweb"
import { TonClient } from "@ton/ton"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3001"

// Testnet RPC URLs
const ETHEREUM_GOERLI_RPC = process.env.NEXT_PUBLIC_ETHEREUM_GOERLI_RPC!
const BSC_TESTNET_RPC = process.env.NEXT_PUBLIC_BSC_TESTNET_RPC!
const POLYGON_MUMBAI_RPC = process.env.NEXT_PUBLIC_POLYGON_MUMBAI_RPC!
const ARBITRUM_GOERLI_RPC = process.env.NEXT_PUBLIC_ARBITRUM_GOERLI_RPC!
const TRON_NILE_RPC = process.env.NEXT_PUBLIC_TRON_NILE_RPC!
const TON_TESTNET_RPC = process.env.NEXT_PUBLIC_TON_TESTNET_RPC!

let token: string | null = null

export async function register(email: string, password: string) {
  const response = await axios.post(`${API_BASE_URL}/api/register`, { email, password })
  token = response.data.token
  return response.data
}

export async function login(email: string, password: string) {
  const response = await axios.post(`${API_BASE_URL}/api/login`, { email, password })
  token = response.data.token
  return response.data
}

export async function getBalance() {
  const response = await axios.get(`${API_BASE_URL}/api/balance`, {
    headers: { Authorization: `Bearer ${token}` },
  })
  return response.data
}

export async function getTokens() {
  const response = await axios.get(`${API_BASE_URL}/api/tokens`, {
    headers: { Authorization: `Bearer ${token}` },
  })
  return response.data
}

export async function getAnnouncements() {
  const response = await axios.get(`${API_BASE_URL}/api/announcements`, {
    headers: { Authorization: `Bearer ${token}` },
  })
  return response.data
}

export async function sendTransaction(network: string, recipient: string, amount: string, tokenSymbol: string) {
  const response = await axios.post(
    `${API_BASE_URL}/api/send-transaction`,
    { network, recipient, amount, token: tokenSymbol },
    { headers: { Authorization: `Bearer ${token}` } },
  )
  return response.data
}

export async function getAddress(network: string) {
  const response = await axios.get(`${API_BASE_URL}/api/address/${network}`, {
    headers: { Authorization: `Bearer ${token}` },
  })
  return response.data.address
}

export async function getSwapRate(fromToken: string, toToken: string, amount: string) {
  const response = await axios.get(`${API_BASE_URL}/api/swap/rate`, {
    params: { fromToken, toToken, amount },
    headers: { Authorization: `Bearer ${token}` },
  })
  return response.data.rate
}

export async function executeSwap(fromToken: string, toToken: string, amount: string) {
  const response = await axios.post(
    `${API_BASE_URL}/api/swap`,
    { fromToken, toToken, amount },
    { headers: { Authorization: `Bearer ${token}` } },
  )
  return response.data
}

export async function getTransactionHistory() {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/transaction-history`, {
      headers: { Authorization: `Bearer ${token}` },
    })
    return response.data
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.code === "ECONNABORTED") {
        throw new Error("Request timed out. Please try again.")
      }
      if (error.response) {
        throw new Error(`Server error: ${error.response.status}`)
      }
      if (error.request) {
        throw new Error("Network error. Please check your internet connection.")
      }
    }
    throw new Error("An unexpected error occurred. Please try again.")
  }
}

export async function getTokenPrices(symbols: string[]) {
  try {
    console.log("Fetching token prices for:", symbols)
    const response = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${symbols.join(",")}&vs_currencies=usd&include_24hr_change=true`,
      {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      },
    )

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    console.log("Received price data:", data)

    if (Object.keys(data).length === 0) {
      console.warn("Empty response from CoinGecko API")
      return generateFallbackPrices(symbols)
    }

    return data
  } catch (error) {
    console.error("Failed to fetch token prices:", error)
    return generateFallbackPrices(symbols)
  }
}

function generateFallbackPrices(symbols: string[]) {
  console.log("Generating fallback prices for:", symbols)
  return symbols.reduce((acc, symbol) => {
    acc[symbol.toLowerCase()] = { usd: 0, usd_24h_change: 0 }
    return acc
  }, {})
}

export async function generateTestnetAddresses() {
  let addresses = JSON.parse(localStorage.getItem("testnetAddresses") || "{}")

  if (Object.keys(addresses).length === 0) {
    const isSolanaConnected = await checkSolanaConnection()
    addresses = {
      ETH_GOERLI: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}`,
      BSC_TESTNET: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}`,
      MATIC_MUMBAI: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}`,
      AVAX_FUJI: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}`,
      ARB_GOERLI: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}`,
      SOL_DEVNET: isSolanaConnected ? new web3.Keypair().publicKey.toBase58() : "Connection Error",
      TON_TESTNET: `0:${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}`,
      TRX_NILE: `T${Array.from({ length: 33 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}`,
    }
    localStorage.setItem("testnetAddresses", JSON.stringify(addresses))
  }

  return addresses
}

export async function getTestnetBalance(network: string, address: string): Promise<string> {
  console.log(`Attempting to fetch balance for ${network} at address ${address}`)
  try {
    if (!address || address === "Connection Error") {
      throw new Error(`Invalid address for ${network}: ${address}`)
    }

    let balance: string
    switch (network) {
      case "ETH_GOERLI":
        balance = await getGoerliEthBalance(address)
        break
      case "SOL_DEVNET":
        balance = await getSolanaDevnetBalance(address)
        break
      case "BSC_TESTNET":
        balance = await getBscTestnetBalance(address)
        break
      case "MATIC_MUMBAI":
        balance = await getMaticMumbaiBalance(address)
        break
      case "ARB_GOERLI":
        balance = await getArbitrumGoerliBalance(address)
        break
      case "TON_TESTNET":
        balance = await getTonTestnetBalance(address)
        break
      case "TRX_NILE":
        balance = await getTronNileBalance(address)
        break
      default:
        throw new Error(`Unsupported testnet: ${network}`)
    }

    if (isNaN(Number.parseFloat(balance))) {
      throw new Error(`Invalid balance received for ${network}: ${balance}`)
    }

    return balance
  } catch (error) {
    console.error(`Error in getTestnetBalance for ${network}:`, error)
    if (error instanceof Error) {
      console.error("Error message:", error.message)
      console.error("Error stack:", error.stack)
    }
    throw error
  }
}

async function getGoerliEthBalance(address: string): Promise<string> {
  const provider = new ethers.providers.JsonRpcProvider(ETHEREUM_GOERLI_RPC)
  const balance = await provider.getBalance(address)
  return ethers.utils.formatEther(balance)
}

async function getSolanaDevnetBalance(address: string): Promise<string> {
  const connection = new web3.Connection(web3.clusterApiUrl("devnet"), "confirmed")
  const publicKey = new web3.PublicKey(address)
  const balance = await connection.getBalance(publicKey)
  return (balance / web3.LAMPORTS_PER_SOL).toFixed(4)
}

async function getBscTestnetBalance(address: string): Promise<string> {
  const provider = new ethers.providers.JsonRpcProvider(BSC_TESTNET_RPC)
  const balance = await provider.getBalance(address)
  return ethers.utils.formatEther(balance)
}

async function getMaticMumbaiBalance(address: string): Promise<string> {
  const provider = new ethers.providers.JsonRpcProvider(POLYGON_MUMBAI_RPC)
  const balance = await provider.getBalance(address)
  return ethers.utils.formatEther(balance)
}

async function getArbitrumGoerliBalance(address: string): Promise<string> {
  const provider = new ethers.providers.JsonRpcProvider(ARBITRUM_GOERLI_RPC)
  const balance = await provider.getBalance(address)
  return ethers.utils.formatEther(balance)
}

async function getTonTestnetBalance(address: string): Promise<string> {
  const client = new TonClient({ endpoint: TON_TESTNET_RPC })
  const balance = await client.getBalance(address)
  return (Number(balance) / 1e9).toFixed(4) // TON uses 9 decimal places
}

async function getTronNileBalance(address: string): Promise<string> {
  const tronWeb = new TronWeb({
    fullHost: TRON_NILE_RPC,
    headers: { "TRON-PRO-API-KEY": "your-api-key-here" },
  })
  const balance = await tronWeb.trx.getBalance(address)
  return (balance / 1e6).toFixed(4) // TRX uses 6 decimal places
}

async function checkSolanaConnection(): Promise<boolean> {
  try {
    const connection = new web3.Connection(web3.clusterApiUrl("devnet"), "confirmed")
    const version = await connection.getVersion()
    console.log("Solana connection successful. Version:", version)
    return true
  } catch (error) {
    console.error("Failed to connect to Solana devnet:", error)
    return false
  }
}

export async function requestTestnetTokens(network: string, address: string) {
  console.log(`Requesting testnet tokens for ${network} at address ${address}`)
  try {
    let result: { success: boolean; message: string }
    switch (network) {
      case "ETH_GOERLI":
        result = await requestGoerliEth(address)
        break
      case "SOL_DEVNET":
        result = await requestSolanaDevnetTokens(address)
        break
      case "BSC_TESTNET":
        result = await requestBscTestnetTokens(address)
        break
      case "MATIC_MUMBAI":
        result = await requestMaticMumbaiTokens(address)
        break
      case "ARB_GOERLI":
        result = await requestArbitrumGoerliTokens(address)
        break
      case "TON_TESTNET":
        result = await requestTonTestnetTokens(address)
        break
      case "TRX_NILE":
        result = await requestTronNileTokens(address)
        break
      default:
        throw new Error(`Unsupported testnet: ${network}`)
    }

    if (!result.success) {
      throw new Error(`Failed to request tokens for ${network}: ${result.message}`)
    }

    return result
  } catch (error) {
    console.error(`Error in requestTestnetTokens for ${network}:`, error)
    if (error instanceof Error) {
      console.error("Error message:", error.message)
      console.error("Error stack:", error.stack)
    }
    return { success: false, message: `Failed to request testnet tokens for ${network}: ${error.message}` }
  }
}

async function requestGoerliEth(address: string) {
  const response = await axios.get(`https://goerli-faucet.pk910.de/`, {
    params: { address: address },
  })
  if (response.data.success) {
    return { success: true, message: "Goerli ETH requested successfully" }
  } else {
    throw new Error("Failed to request Goerli ETH")
  }
}

async function requestSolanaDevnetTokens(address: string) {
  const connection = new web3.Connection(web3.clusterApiUrl("devnet"), "confirmed")
  const publicKey = new web3.PublicKey(address)
  const airdropSignature = await connection.requestAirdrop(publicKey, 1 * web3.LAMPORTS_PER_SOL)
  await connection.confirmTransaction(airdropSignature)
  return { success: true, message: "Solana devnet tokens requested successfully" }
}

async function requestBscTestnetTokens(address: string) {
  const response = await axios.get(`https://testnet.binance.org/faucet-smart`, {
    params: { address: address },
  })
  if (response.data.success) {
    return { success: true, message: "BSC testnet tokens requested successfully" }
  } else {
    throw new Error("Failed to request BSC testnet tokens")
  }
}

async function requestMaticMumbaiTokens(address: string) {
  const response = await axios.post(`https://faucet.polygon.technology/`, {
    address: address,
    network: "mumbai",
    token: "MATIC",
  })
  if (response.data.success) {
    return { success: true, message: "Matic Mumbai tokens requested successfully" }
  } else {
    throw new Error("Failed to request Matic Mumbai tokens")
  }
}

async function requestArbitrumGoerliTokens(address: string) {
  const response = await axios.post(`https://faucet.triangleplatform.com/arbitrum/goerli`, {
    address: address,
  })
  if (response.data.success) {
    return { success: true, message: "Arbitrum Goerli tokens requested successfully" }
  } else {
    throw new Error("Failed to request Arbitrum Goerli tokens")
  }
}

async function requestTonTestnetTokens(address: string) {
  const response = await axios.post(`https://faucet.tonhub.com/`, {
    address: address,
  })
  if (response.data.success) {
    return { success: true, message: "TON testnet tokens requested successfully" }
  } else {
    throw new Error("Failed to request TON testnet tokens")
  }
}

async function requestTronNileTokens(address: string) {
  const response = await axios.post(`https://nileex.io/join/getJoinPage`, {
    address: address,
  })
  if (response.data.success) {
    return { success: true, message: "Tron Nile tokens requested successfully" }
  } else {
    throw new Error("Failed to request Tron Nile tokens")
  }
}

export async function sendTestnetTransaction(tokenId: string, recipient: string, amount: string) {
  const validation = validateTransaction(tokenId, recipient, amount)
  if (!validation.isValid) {
    return { success: false, message: validation.error }
  }

  console.log(`Sending testnet transaction on ${tokenId} to ${recipient} with amount ${amount}`)
  try {
    let result: { success: boolean; txHash: string }
    switch (tokenId) {
      case "ETH_GOERLI":
        result = await sendGoerliEthTransaction(recipient, amount)
        break
      case "SOL_DEVNET":
        result = await sendSolanaDevnetTransaction(recipient, amount)
        break
      case "BSC_TESTNET":
        result = await sendBscTestnetTransaction(recipient, amount)
        break
      case "MATIC_MUMBAI":
        result = await sendMaticMumbaiTransaction(recipient, amount)
        break
      case "ARB_GOERLI":
        result = await sendArbitrumGoerliTransaction(recipient, amount)
        break
      case "TON_TESTNET":
        result = await sendTonTestnetTransaction(recipient, amount)
        break
      case "TRX_NILE":
        result = await sendTronNileTransaction(recipient, amount)
        break
      default:
        throw new Error(`Unsupported testnet: ${tokenId}`)
    }

    if (!result.success || !result.txHash) {
      throw new Error(`Transaction failed for ${tokenId}`)
    }

    return { success: true, txHash: result.txHash, message: `Transaction sent successfully on ${tokenId}` }
  } catch (error) {
    console.error(`Error in sendTestnetTransaction for ${tokenId}:`, error)
    if (error instanceof Error) {
      console.error("Error message:", error.message)
      console.error("Error stack:", error.stack)
    }
    return { success: false, txHash: "", message: `Failed to send transaction on ${tokenId}: ${error.message}` }
  }
}

async function sendGoerliEthTransaction(recipient: string, amount: string) {
  const provider = new ethers.providers.JsonRpcProvider(ETHEREUM_GOERLI_RPC)
  const signer = new ethers.Wallet(process.env.GOERLI_PRIVATE_KEY!, provider)
  const tx = await signer.sendTransaction({
    to: recipient,
    value: ethers.utils.parseEther(amount),
  })
  await tx.wait()
  return { success: true, txHash: tx.hash }
}

async function sendSolanaDevnetTransaction(recipient: string, amount: string) {
  const connection = new web3.Connection(web3.clusterApiUrl("devnet"), "confirmed")
  const senderKeypair = web3.Keypair.fromSecretKey(Uint8Array.from(JSON.parse(process.env.SOLANA_DEVNET_PRIVATE_KEY!)))
  const transaction = new web3.Transaction().add(
    web3.SystemProgram.transfer({
      fromPubkey: senderKeypair.publicKey,
      toPubkey: new web3.PublicKey(recipient),
      lamports: web3.LAMPORTS_PER_SOL * Number.parseFloat(amount),
    }),
  )
  const signature = await web3.sendAndConfirmTransaction(connection, transaction, [senderKeypair])
  return { success: true, txHash: signature }
}

async function sendBscTestnetTransaction(recipient: string, amount: string) {
  const provider = new ethers.providers.JsonRpcProvider(BSC_TESTNET_RPC)
  const signer = new ethers.Wallet(process.env.BSC_TESTNET_PRIVATE_KEY!, provider)
  const tx = await signer.sendTransaction({
    to: recipient,
    value: ethers.utils.parseEther(amount),
  })
  await tx.wait()
  return { success: true, txHash: tx.hash }
}

async function sendMaticMumbaiTransaction(recipient: string, amount: string) {
  const provider = new ethers.providers.JsonRpcProvider(POLYGON_MUMBAI_RPC)
  const signer = new ethers.Wallet(process.env.MATIC_MUMBAI_PRIVATE_KEY!, provider)
  const tx = await signer.sendTransaction({
    to: recipient,
    value: ethers.utils.parseEther(amount),
  })
  await tx.wait()
  return { success: true, txHash: tx.hash }
}

async function sendArbitrumGoerliTransaction(recipient: string, amount: string) {
  const provider = new ethers.providers.JsonRpcProvider(ARBITRUM_GOERLI_RPC)
  const signer = new ethers.Wallet(process.env.ARBITRUM_GOERLI_PRIVATE_KEY!, provider)
  const tx = await signer.sendTransaction({
    to: recipient,
    value: ethers.utils.parseEther(amount),
  })
  await tx.wait()
  return { success: true, txHash: tx.hash }
}

async function sendTonTestnetTransaction(recipient: string, amount: string) {
  const client = new TonClient({ endpoint: TON_TESTNET_RPC })
  const wallet = client.openWallet(process.env.TON_TESTNET_PRIVATE_KEY!)
  const transfer = await wallet.transfer({
    to: recipient,
    amount: BigInt(Number.parseFloat(amount) * 1e9), // Convert to nanotons
    bounce: false,
  })
  return { success: true, txHash: transfer.txid }
}

async function sendTronNileTransaction(recipient: string, amount: string) {
  const tronWeb = new TronWeb({
    fullHost: TRON_NILE_RPC,
    privateKey: process.env.TRON_NILE_PRIVATE_KEY,
  })
  const tx = await tronWeb.trx.sendTransaction(recipient, tronWeb.toSun(amount))
  return { success: true, txHash: tx.txid }
}

export async function checkTransactionStatus(
  network: string,
  txHash: string,
): Promise<{ confirmed: boolean; message: string }> {
  try {
    let confirmed: boolean
    switch (network) {
      case "ETH_GOERLI":
        confirmed = await checkEthereumTransactionStatus(ETHEREUM_GOERLI_RPC, txHash)
        break
      case "SOL_DEVNET":
        confirmed = await checkSolanaTransactionStatus(txHash)
        break
      case "BSC_TESTNET":
        confirmed = await checkEthereumTransactionStatus(BSC_TESTNET_RPC, txHash)
        break
      case "MATIC_MUMBAI":
        confirmed = await checkEthereumTransactionStatus(POLYGON_MUMBAI_RPC, txHash)
        break
      case "ARB_GOERLI":
        confirmed = await checkEthereumTransactionStatus(ARBITRUM_GOERLI_RPC, txHash)
        break
      case "TON_TESTNET":
        confirmed = await checkTonTransactionStatus(txHash)
        break
      case "TRX_NILE":
        confirmed = await checkTronTransactionStatus(txHash)
        break
      default:
        throw new Error(`Unsupported testnet: ${network}`)
    }

    return {
      confirmed,
      message: confirmed ? "Transaction confirmed" : "Transaction pending",
    }
  } catch (error) {
    console.error(`Error checking transaction status for ${network}:`, error)
    return {
      confirmed: false,
      message: `Error checking transaction status: ${error.message}`,
    }
  }
}

async function checkEthereumTransactionStatus(rpcUrl: string, txHash: string): Promise<boolean> {
  const provider = new ethers.providers.JsonRpcProvider(rpcUrl)
  const tx = await provider.getTransaction(txHash)
  return tx && tx.confirmations > 0
}

async function checkSolanaTransactionStatus(txHash: string): Promise<boolean> {
  const connection = new web3.Connection(web3.clusterApiUrl("devnet"), "confirmed")
  const result = await connection.getSignatureStatus(txHash)
  return result.value !== null && result.value.confirmationStatus === "finalized"
}

async function checkTonTransactionStatus(txHash: string): Promise<boolean> {
  const client = new TonClient({ endpoint: TON_TESTNET_RPC })
  const tx = await client.getTransaction(txHash)
  return tx !== null
}

async function checkTronTransactionStatus(txHash: string): Promise<boolean> {
  const tronWeb = new TronWeb({ fullHost: TRON_NILE_RPC })
  const tx = await tronWeb.trx.getTransaction(txHash)
  return tx !== null && tx.ret && tx.ret[0].contractRet === "SUCCESS"
}

export function validateTransaction(
  tokenId: string,
  recipient: string,
  amount: string,
): { isValid: boolean; error?: string } {
  // Validate token ID
  if (
    !["SOL_DEVNET", "ETH_GOERLI", "BSC_TESTNET", "MATIC_MUMBAI", "ARB_GOERLI", "TON_TESTNET", "TRX_NILE"].includes(
      tokenId,
    )
  ) {
    return { isValid: false, error: "Invalid token selected" }
  }

  // Validate recipient address
  const addressRegex = /^0x[a-fA-F0-9]{40}$|^T[a-fA-F0-9]{33}$|^[a-zA-Z0-9]{34,44}$/
  if (!addressRegex.test(recipient)) {
    return { isValid: false, error: "Invalid recipient address" }
  }

  // Validate amount
  const amountNum = Number.parseFloat(amount)
  if (isNaN(amountNum) || amountNum <= 0) {
    return { isValid: false, error: "Invalid amount" }
  }

  return { isValid: true }
}

