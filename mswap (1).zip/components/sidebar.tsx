import { Home, Repeat, Settings, HelpCircle, FileText } from "lucide-react"
import Link from "next/link"

export default function Sidebar() {
  return (
    <aside className="bg-green-900/50 backdrop-blur-md w-64 border-r border-green-700">
      <nav className="mt-10">
        <Link href="/" className="flex items-center px-6 py-2 text-white hover:bg-green-700">
          <Home className="mr-3" />
          Dashboard
        </Link>
        <Link href="/swap" className="flex items-center px-6 py-2 mt-4 text-white hover:bg-green-700">
          <Repeat className="mr-3" />
          Swap
        </Link>
        <Link href="/settings" className="flex items-center px-6 py-2 mt-4 text-white hover:bg-green-700">
          <Settings className="mr-3" />
          Settings
        </Link>
        <Link href="/kyc" className="flex items-center px-6 py-2 mt-4 text-white hover:bg-green-700">
          <FileText className="mr-3" />
          KYC
        </Link>
        <Link href="/help" className="flex items-center px-6 py-2 mt-4 text-white hover:bg-green-700">
          <HelpCircle className="mr-3" />
          Help
        </Link>
      </nav>
    </aside>
  )
}

