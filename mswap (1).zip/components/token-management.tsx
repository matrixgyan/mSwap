import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { addToken } from "@/lib/api"

export function TokenManagement() {
  const [tokenAddress, setTokenAddress] = useState("")
  const [tokenSymbol, setTokenSymbol] = useState("")

  const handleAddToken = async () => {
    try {
      await addToken({ address: tokenAddress, symbol: tokenSymbol })
      // Reset form and maybe show a success message
      setTokenAddress("")
      setTokenSymbol("")
    } catch (error) {
      console.error("Failed to add token:", error)
    }
  }

  return (
    <Card className="bg-green-800/50 backdrop-blur-md border-green-600/50">
      <CardHeader>
        <CardTitle className="text-white">Add Custom Token</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input
            type="text"
            placeholder="Token Address"
            value={tokenAddress}
            onChange={(e) => setTokenAddress(e.target.value)}
            className="bg-green-700/50 border-green-600/50 text-white placeholder-green-300/50"
          />
          <Input
            type="text"
            placeholder="Token Symbol"
            value={tokenSymbol}
            onChange={(e) => setTokenSymbol(e.target.value)}
            className="bg-green-700/50 border-green-600/50 text-white placeholder-green-300/50"
          />
          <Button onClick={handleAddToken} className="w-full bg-green-600 hover:bg-green-700 text-white">
            Add Token
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

