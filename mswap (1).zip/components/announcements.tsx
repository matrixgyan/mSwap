import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function Announcements({ announcements }) {
  return (
    <Card className="bg-green-800/50 backdrop-blur-md border-green-600/50">
      <CardHeader>
        <CardTitle className="text-white">Announcements</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {announcements.map((announcement, index) => (
            <li key={index} className="text-white border-b border-green-700 pb-2">
              {announcement}
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

