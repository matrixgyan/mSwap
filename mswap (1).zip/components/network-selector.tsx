"use client"

import { useState } from "react"
import { Globe, ChevronRight, Plus, Check } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { AddCustomNetworkModal } from "./add-custom-network-modal"
import { addNativeToken } from "@/utils/networkUtils"

const mainnetNetworks = {
  "All Networks": { id: "ALL", name: "All Networks", icon: "/all-networks-icon.svg" },
  "Layer 1 Networks": [
    { id: "ETH", name: "Ethereum", icon: "https://cryptologos.cc/logos/ethereum-eth-logo.png" },
    { id: "SOL", name: "Solana", icon: "https://cryptologos.cc/logos/solana-sol-logo.png" },
    { id: "BTC", name: "Bitcoin", icon: "https://cryptologos.cc/logos/bitcoin-btc-logo.png" },
    { id: "TRX", name: "Tron", icon: "https://cryptologos.cc/logos/tron-trx-logo.png" },
    { id: "TON", name: "Toncoin", icon: "https://cryptologos.cc/logos/toncoin-ton-logo.png" },
    { id: "ADA", name: "Cardano", icon: "https://cryptologos.cc/logos/cardano-ada-logo.png" },
    { id: "DOT", name: "Polkadot", icon: "https://cryptologos.cc/logos/polkadot-new-dot-logo.png" },
    { id: "AVAX", name: "Avalanche", icon: "https://cryptologos.cc/logos/avalanche-avax-logo.png" },
    { id: "BNB", name: "Binance Coin", icon: "https://cryptologos.cc/logos/bnb-bnb-logo.png" },
  ],
  "Layer 2 Networks": [
    { id: "MATIC", name: "Polygon", icon: "https://cryptologos.cc/logos/polygon-matic-logo.png" },
    { id: "ARB", name: "Arbitrum", icon: "https://cryptologos.cc/logos/arbitrum-arb-logo.png" },
    { id: "OP", name: "Optimism", icon: "https://cryptologos.cc/logos/optimism-ethereum-op-logo.png" },
    { id: "IMX", name: "Immutable X", icon: "https://cryptologos.cc/logos/immutable-x-imx-logo.png" },
    { id: "METIS", name: "Metis", icon: "https://cryptologos.cc/logos/metis-metis-logo.png" },
  ],
}

const testnetNetworks = {
  "All Networks": { id: "ALL", name: "All Networks", icon: "/all-networks-icon.svg" },
  "Testnet Networks": [
    { id: "ETH_GOERLI", name: "Ethereum Goerli", icon: "https://cryptologos.cc/logos/ethereum-eth-logo.png" },
    { id: "SOL_DEVNET", name: "Solana Devnet", icon: "https://cryptologos.cc/logos/solana-sol-logo.png" },
    { id: "BSC_TESTNET", name: "BSC Testnet", icon: "https://cryptologos.cc/logos/bnb-bnb-logo.png" },
    { id: "MATIC_MUMBAI", name: "Polygon Mumbai", icon: "https://cryptologos.cc/logos/polygon-matic-logo.png" },
    { id: "ARB_GOERLI", name: "Arbitrum Goerli", icon: "https://cryptologos.cc/logos/arbitrum-arb-logo.png" },
    { id: "TON_TESTNET", name: "TON Testnet", icon: "https://cryptologos.cc/logos/toncoin-ton-logo.png" },
    { id: "TRX_NILE", name: "Tron Nile", icon: "https://cryptologos.cc/logos/tron-trx-logo.png" },
  ],
}

export function NetworkSelector({ selectedNetwork, onNetworkChange, testnetMode }) {
  const [isOpen, setIsOpen] = useState(false)
  const [showAddCustomNetwork, setShowAddCustomNetwork] = useState(false)

  const handleNetworkSelect = (networkId: string) => {
    const selectedNetwork = Object.values(testnetMode ? testnetNetworks : mainnetNetworks)
      .flat()
      .find((network: any) => network.id === networkId)

    if (selectedNetwork) {
      onNetworkChange(networkId)
      addNativeToken(selectedNetwork)
    }
    setIsOpen(false)
  }

  const selectedNetworkInfo =
    Object.values(testnetMode ? testnetNetworks : mainnetNetworks)
      .flat()
      .find((network: any) => network.id === selectedNetwork) ||
    (testnetMode ? testnetNetworks : mainnetNetworks)["All Networks"]

  const networks = testnetMode ? testnetNetworks : mainnetNetworks

  return (
    <>
      <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="w-12 h-12 rounded-full bg-[#1a3a1a] border-[#2a4a2a] hover:bg-[#2a4a2a]"
          >
            <Globe className="w-6 h-6 text-white" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-96 max-h-[80vh] overflow-y-auto bg-[#0f1f0f] border-[#1a3a1a] text-white rounded-xl">
          <DropdownMenuItem
            onClick={() => handleNetworkSelect("ALL")}
            className="flex items-center gap-3 px-4 py-3 hover:bg-[#1a3a1a] rounded-lg m-1"
          >
            <div className="flex items-center gap-3 flex-1">
              <Globe className="w-6 h-6 text-white" />
              <span className="text-lg font-semibold">All Networks</span>
            </div>
            {selectedNetwork === "ALL" && <Check className="w-5 h-5 ml-auto" />}
          </DropdownMenuItem>
          <DropdownMenuSeparator className="bg-[#1a3a1a]" />
          {Object.entries(networks).map(
            ([category, categoryNetworks]: [string, any]) =>
              category !== "All Networks" && (
                <DropdownMenuSub key={category}>
                  <DropdownMenuSubTrigger className="flex items-center justify-between px-4 py-3 hover:bg-[#1a3a1a] rounded-lg m-1">
                    <span className="text-lg font-semibold">{category}</span>
                    <ChevronRight className="w-5 h-5" />
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent className="bg-[#0f1f0f] border-[#1a3a1a] text-white rounded-xl">
                    {Array.isArray(categoryNetworks) ? (
                      categoryNetworks.map((network: any) => (
                        <DropdownMenuItem
                          key={network.id}
                          onClick={() => handleNetworkSelect(network.id)}
                          className="flex items-center gap-3 px-4 py-3 hover:bg-[#1a3a1a] rounded-lg m-1"
                        >
                          <div className="flex items-center gap-3 flex-1">
                            <img
                              src={network.icon || "/placeholder.svg"}
                              alt={network.name}
                              className="w-8 h-8 rounded-full"
                            />
                            <span className="text-lg font-semibold">{network.name}</span>
                          </div>
                          {selectedNetwork === network.id && <Check className="w-5 h-5 ml-auto" />}
                        </DropdownMenuItem>
                      ))
                    ) : (
                      <DropdownMenuItem
                        onClick={() => handleNetworkSelect(categoryNetworks.id)}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-[#1a3a1a] rounded-lg m-1"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <img
                            src={categoryNetworks.icon || "/placeholder.svg"}
                            alt={categoryNetworks.name}
                            className="w-8 h-8 rounded-full"
                          />
                          <span className="text-lg font-semibold">{categoryNetworks.name}</span>
                        </div>
                        {selectedNetwork === categoryNetworks.id && <Check className="w-5 h-5 ml-auto" />}
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuSubContent>
                </DropdownMenuSub>
              ),
          )}
          <DropdownMenuSeparator className="bg-[#1a3a1a]" />
          <DropdownMenuItem
            onClick={() => {
              setIsOpen(false)
              setShowAddCustomNetwork(true)
            }}
            className="flex items-center gap-2 px-4 py-3 hover:bg-[#1a3a1a] rounded-lg m-1"
          >
            <Plus className="w-5 h-5" />
            <span className="text-lg font-semibold">Add Custom Network</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <AddCustomNetworkModal
        isOpen={showAddCustomNetwork}
        onClose={() => setShowAddCustomNetwork(false)}
        onAddNetwork={(newNetwork) => {
          // Add the new network to the list
          const updatedNetworks = { ...networks }
          updatedNetworks[newNetwork.networkType].push({
            id: newNetwork.symbol,
            name: newNetwork.name,
            icon: "/placeholder.svg",
            ...newNetwork,
          })
          // You might want to update the state or context with the new networks list here

          // Add the native token
          addNativeToken(newNetwork)
        }}
      />
    </>
  )
}

