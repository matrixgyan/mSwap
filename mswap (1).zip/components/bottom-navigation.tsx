import { HomeIcon, ArrowUpDown, Layers, User } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

export default function BottomNavigation() {
  const pathname = usePathname()

  const navItems = [
    { icon: HomeIcon, label: "Home", href: "/" },
    { icon: ArrowUpDown, label: "Swap", href: "/swap" },
    { icon: Layers, label: "Tools", href: "/tools" },
    { icon: User, label: "Menu", href: "/menu" },
  ]

  return (
    <nav className="grid grid-cols-4 bg-[#0f1f0f] border-t border-[#1a3a1a] py-2">
      {navItems.map((item) => (
        <Link
          key={item.label}
          href={item.href}
          className={cn(
            "flex flex-col items-center gap-1",
            pathname === item.href ? "text-[#4caf50]" : "text-gray-400",
          )}
        >
          <item.icon className="w-6 h-6" />
          <span className="text-xs">{item.label}</span>
        </Link>
      ))}
    </nav>
  )
}

