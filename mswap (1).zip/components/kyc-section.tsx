"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { submitKYC } from "@/lib/api"

export function KYCSection() {
  const [documentType, setDocumentType] = useState("")
  const [file, setFile] = useState<File | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0])
    }
  }

  const handleSubmitKYC = async () => {
    if (!file || !documentType) {
      alert("Please select a document type and upload a file.")
      return
    }

    try {
      const formData = new FormData()
      formData.append("document", file)
      formData.append("documentType", documentType)

      await submitKYC(formData)
      alert("KYC documents submitted successfully!")
    } catch (error) {
      console.error("Failed to submit KYC:", error)
      alert("Failed to submit KYC documents. Please try again.")
    }
  }

  return (
    <Card className="bg-green-800/50 backdrop-blur-md border-green-600/50">
      <CardHeader>
        <CardTitle className="text-white">KYC Verification</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid w-full items-center gap-4">
          <Select onValueChange={setDocumentType}>
            <SelectTrigger className="bg-green-700/50 border-green-600/50 text-white">
              <SelectValue placeholder="Select Document Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="passport">Passport</SelectItem>
              <SelectItem value="driverLicense">Driver's License</SelectItem>
              <SelectItem value="idCard">National ID Card</SelectItem>
            </SelectContent>
          </Select>
          <Input type="file" onChange={handleFileChange} className="bg-green-700/50 border-green-600/50 text-white" />
          <Button onClick={handleSubmitKYC} className="bg-green-600 hover:bg-green-700 text-white">
            Submit KYC Documents
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

