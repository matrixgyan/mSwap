import { Card } from "@/components/ui/card"
import { Bell, Settings, ArrowDown } from "lucide-react"

export default function AnnouncementCard({ title, description, type }) {
  const Icon = type === "security" ? Settings : Bell

  return (
    <Card className="bg-[#0f1f0f] border-[#1a3a1a] rounded-2xl p-4 mb-4">
      <div className="flex items-center gap-4">
        <div className="bg-[#1a3a1a] p-2 rounded-lg">
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="text-white font-semibold">{title}</h3>
          <p className="text-gray-400">{description}</p>
        </div>
        <ArrowDown className="w-6 h-6 text-gray-400" />
      </div>
    </Card>
  )
}

