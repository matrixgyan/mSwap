import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, ArrowLeftRight, Settings, User, UserPlus } from "lucide-react"

export default function BottomMenu() {
  const pathname = usePathname()

  const menuItems = [
    { icon: Home, label: "Home", href: "/" },
    { icon: ArrowLeftRight, label: "Swap", href: "/swap" },
    { icon: Settings, label: "Settings", href: "/settings" },
    { icon: User, label: "Profile", href: "/profile" },
    { icon: UserPlus, label: "Register", href: "/register" },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#0f1f0f] border-t border-[#1a3a1a] py-2">
      <div className="flex justify-around">
        {menuItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div
              className={`flex flex-col items-center ${pathname === item.href ? "text-[#4caf50]" : "text-gray-400"}`}
            >
              <item.icon className="w-6 h-6" />
              <span className="text-xs mt-1">{item.label}</span>
            </div>
          </Link>
        ))}
      </div>
    </nav>
  )
}

