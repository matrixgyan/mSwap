import { Button } from "@/components/ui/button"

export default function Header({ uid }: { uid: string }) {
  return (
    <header className="bg-green-900/50 backdrop-blur-md border-b border-green-700 py-4 px-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">mSwap</h1>
        <div className="flex items-center space-x-4">
          <span className="text-green-300">UID: {uid}</span>
          <Button variant="outline" className="text-white border-white hover:bg-green-700">
            Disconnect
          </Button>
        </div>
      </div>
    </header>
  )
}

