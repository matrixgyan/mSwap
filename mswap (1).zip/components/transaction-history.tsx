import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function TransactionHistory() {
  const transactions = [
    { id: 1, type: "Sent", amount: "-0.1 ETH", date: "2023-05-01" },
    { id: 2, type: "Received", amount: "+0.5 SOL", date: "2023-04-30" },
    { id: 3, type: "Swapped", amount: "0.2 ETH -> 10 TON", date: "2023-04-29" },
  ]

  return (
    <Card className="bg-green-800/50 backdrop-blur-md border-green-600/50">
      <CardHeader>
        <CardTitle className="text-white">Transaction History</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {transactions.map((tx) => (
            <li key={tx.id} className="flex justify-between text-white border-b border-green-700 pb-2">
              <span className="font-semibold">{tx.type}</span>
              <span className={tx.amount.startsWith("+") ? "text-green-300" : "text-red-300"}>{tx.amount}</span>
              <span className="text-green-300">{tx.date}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

