"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { getUserSupport } from "@/lib/api"

export function AISupportChat() {
  const [query, setQuery] = useState("")
  const [response, setResponse] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    try {
      const result = await getUserSupport(query)
      setResponse(result.response)
    } catch (error) {
      console.error("AI support error:", error)
      setResponse("Sorry, I'm having trouble right now. Please try again later.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="bg-green-800/50 backdrop-blur-md border-green-600/50">
      <CardHeader>
        <CardTitle className="text-white">AI Support Chat</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask for help..."
            className="bg-green-700/50 border-green-600/50 text-white placeholder-green-300/50"
          />
          <Button type="submit" disabled={isLoading} className="bg-green-600 hover:bg-green-700 text-white">
            {isLoading ? "Thinking..." : "Ask"}
          </Button>
        </form>
        {response && (
          <div className="mt-4 p-4 bg-green-700/50 border border-green-600/50 rounded-md text-white">{response}</div>
        )}
      </CardContent>
    </Card>
  )
}

