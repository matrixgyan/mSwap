"use client"

import { useState } from "react"
import { Eye, ArrowUp, ArrowDown, ArrowUpDown, List } from "lucide-react"
import { Card } from "@/components/ui/card"
import Link from "next/link"

export default function BalanceCard({ balance, change }) {
  const [showBalance, setShowBalance] = useState(true)

  return (
    <Card className="bg-gradient-to-br from-[#0f1f0f] to-[#0a150a] border-[#1a3a1a] rounded-3xl p-6 mb-4">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-2">
          <span className="text-gray-400">Available assets</span>
          <button onClick={() => setShowBalance(!showBalance)}>
            <Eye className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        <div className="flex items-center gap-2 text-red-400">
          <span>${change.toFixed(2)}</span>
          <span>({((change / balance) * 100).toFixed(2)}%)</span>
        </div>
      </div>
      <div className="mb-8">
        <div className="flex items-baseline gap-2">
          <span className="text-4xl font-bold text-white">{showBalance ? `$${balance.toFixed(2)}` : "******"}</span>
          <span className="text-gray-400">USD</span>
        </div>
        <div className="h-1 w-full bg-[#1a3a1a] rounded-full mt-4" />
      </div>
      <div className="grid grid-cols-4 gap-4">
        {[
          { icon: ArrowUp, label: "Send", href: "/send" },
          { icon: ArrowDown, label: "Receive", href: "/receive" },
          { icon: ArrowUpDown, label: "Swap", href: "/swap" },
          { icon: List, label: "History", href: "/history" },
        ].map((item) => (
          <Link key={item.label} href={item.href} className="flex flex-col items-center gap-2">
            <div className="bg-[#1a3a1a] p-3 rounded-full">
              <item.icon className="w-6 h-6 text-white" />
            </div>
            <span className="text-gray-400 text-sm">{item.label}</span>
          </Link>
        ))}
      </div>
    </Card>
  )
}

