"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getSwapRate, executeSwap } from "@/lib/api"

export function SwapSection() {
  const [fromToken, setFromToken] = useState("")
  const [toToken, setToToken] = useState("")
  const [amount, setAmount] = useState("")
  const [rate, setRate] = useState(null)
  const [fee, setFee] = useState(null)

  const handleGetRate = async () => {
    try {
      const { rate, fee } = await getSwapRate(fromToken, toToken, amount)
      setRate(rate)
      setFee(fee)
    } catch (error) {
      console.error("Failed to get swap rate:", error)
    }
  }

  const handleSwap = async () => {
    try {
      const result = await executeSwap(fromToken, toToken, amount)
      console.log("Swap executed:", result)
      // Handle successful swap (e.g., show success message, update balances)
    } catch (error) {
      console.error("Swap failed:", error)
    }
  }

  return (
    <Card className="bg-green-800/50 backdrop-blur-md border-green-600/50">
      <CardHeader>
        <CardTitle className="text-white">Swap Tokens</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid w-full items-center gap-4">
          <Select onValueChange={setFromToken}>
            <SelectTrigger className="bg-green-700/50 border-green-600/50 text-white">
              <SelectValue placeholder="From Token" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ETH">ETH</SelectItem>
              <SelectItem value="SOL">SOL</SelectItem>
              <SelectItem value="TON">TON</SelectItem>
            </SelectContent>
          </Select>
          <Select onValueChange={setToToken}>
            <SelectTrigger className="bg-green-700/50 border-green-600/50 text-white">
              <SelectValue placeholder="To Token" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ETH">ETH</SelectItem>
              <SelectItem value="SOL">SOL</SelectItem>
              <SelectItem value="TON">TON</SelectItem>
            </SelectContent>
          </Select>
          <Input
            type="number"
            placeholder="Amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="bg-green-700/50 border-green-600/50 text-white placeholder-green-300/50"
          />
          <Button onClick={handleGetRate} className="bg-green-600 hover:bg-green-700 text-white">
            Get Rate
          </Button>
          {rate && fee && (
            <div className="text-white">
              <p>
                Rate: 1 {fromToken} = {rate} {toToken}
              </p>
              <p>
                Fee: {fee} {fromToken}
              </p>
            </div>
          )}
          <Button onClick={handleSwap} className="bg-green-600 hover:bg-green-700 text-white" disabled={!rate}>
            Swap
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

