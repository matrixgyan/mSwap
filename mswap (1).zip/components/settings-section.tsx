"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { updateSettings } from "@/lib/api"

export function SettingsSection() {
  const [pin, setPin] = useState("")
  const [biometrics, setBiometrics] = useState(false)
  const [customRPC, setCustomRPC] = useState("")

  const handleSaveSettings = async () => {
    try {
      await updateSettings({ pin, biometrics, customRPC })
      // Handle successful settings update (e.g., show success message)
    } catch (error) {
      console.error("Failed to update settings:", error)
    }
  }

  return (
    <Card className="bg-green-800/50 backdrop-blur-md border-green-600/50">
      <CardHeader>
        <CardTitle className="text-white">Wallet Settings</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid w-full items-center gap-4">
          <Input
            type="password"
            placeholder="Set PIN"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            className="bg-green-700/50 border-green-600/50 text-white placeholder-green-300/50"
          />
          <div className="flex items-center justify-between">
            <span className="text-white">Enable Biometrics</span>
            <Switch checked={biometrics} onCheckedChange={setBiometrics} />
          </div>
          <Input
            type="text"
            placeholder="Custom RPC URL"
            value={customRPC}
            onChange={(e) => setCustomRPC(e.target.value)}
            className="bg-green-700/50 border-green-600/50 text-white placeholder-green-300/50"
          />
          <Button onClick={handleSaveSettings} className="bg-green-600 hover:bg-green-700 text-white">
            Save Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

