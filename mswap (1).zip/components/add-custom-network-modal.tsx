import { useState } from "react"
import { X } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"

export function AddCustomNetworkModal({ isOpen, onClose, onAddNetwork }) {
  const [newNetwork, setNewNetwork] = useState({
    name: "",
    rpcUrl: "",
    chainId: "",
    symbol: "",
    explorerUrl: "",
    networkType: "Layer 1 Networks",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onAddNetwork(newNetwork)
    setNewNetwork({
      name: "",
      rpcUrl: "",
      chainId: "",
      symbol: "",
      explorerUrl: "",
      networkType: "Layer 1 Networks",
    })
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-[#0f1f0f] text-white border-[#1a3a1a]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Add Custom Network</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Network Name</Label>
            <Input
              id="name"
              value={newNetwork.name}
              onChange={(e) => setNewNetwork({ ...newNetwork, name: e.target.value })}
              placeholder="e.g. My Custom Network"
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="rpcUrl">RPC URL</Label>
            <Input
              id="rpcUrl"
              value={newNetwork.rpcUrl}
              onChange={(e) => setNewNetwork({ ...newNetwork, rpcUrl: e.target.value })}
              placeholder="https://..."
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="chainId">Chain ID</Label>
            <Input
              id="chainId"
              value={newNetwork.chainId}
              onChange={(e) => setNewNetwork({ ...newNetwork, chainId: e.target.value })}
              placeholder="e.g. 1"
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="symbol">Currency Symbol</Label>
            <Input
              id="symbol"
              value={newNetwork.symbol}
              onChange={(e) => setNewNetwork({ ...newNetwork, symbol: e.target.value })}
              placeholder="e.g. ETH"
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="explorerUrl">Block Explorer URL (Optional)</Label>
            <Input
              id="explorerUrl"
              value={newNetwork.explorerUrl}
              onChange={(e) => setNewNetwork({ ...newNetwork, explorerUrl: e.target.value })}
              placeholder="https://..."
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="networkType">Network Type</Label>
            <select
              id="networkType"
              value={newNetwork.networkType}
              onChange={(e) => setNewNetwork({ ...newNetwork, networkType: e.target.value })}
              className="w-full bg-[#1a3a1a] border-[#2a4a2a] text-white rounded-md p-2"
            >
              <option value="Layer 1 Networks">Layer 1 Networks</option>
              <option value="Layer 2 Networks">Layer 2 Networks</option>
              <option value="Layer 3 Networks">Layer 3 Networks</option>
              <option value="DeFi Networks">DeFi Networks</option>
            </select>
          </div>
          <div className="bg-[#1a3a1a] p-4 rounded-lg text-sm text-gray-300">
            <h4 className="font-semibold mb-2">Instructions:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>Enter the details of your custom network carefully.</li>
              <li>Ensure the RPC URL is correct and accessible.</li>
              <li>The Chain ID should be a unique identifier for the network.</li>
              <li>Use a recognizable currency symbol for the network's native token.</li>
              <li>If available, provide the block explorer URL for transaction lookups.</li>
            </ul>
          </div>
          <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
            Add Network
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}

