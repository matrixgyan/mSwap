"use client"

import { useState, useEffect } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { getTokens } from "@/lib/api"
import Link from "next/link"

export default function TokenList() {
  const [tokens, setTokens] = useState([])
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const fetchTokens = async () => {
      const tokensData = await getTokens()
      setTokens(tokensData)
    }
    fetchTokens()
  }, [])

  const filteredTokens = tokens.filter((token) => token.symbol.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="mt-6">
      <div className="relative mb-4">
        <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
        <Input
          type="text"
          placeholder="Search all tokens"
          className="pl-10 bg-[#0f1f0f] border-[#1a3a1a] text-white placeholder:text-gray-400 rounded-xl"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="flex justify-between text-gray-400 mb-2 px-2">
        <span>Token</span>
        <span>Balance</span>
      </div>

      {filteredTokens.map((token) => (
        <Link
          key={token.symbol}
          href={`/token/${token.symbol}`}
          className="flex items-center justify-between py-4 border-b border-[#1a3a1a]"
        >
          <div className="flex items-center gap-4">
            <img src={token.logo || "/placeholder.svg"} alt={token.symbol} className="w-10 h-10 rounded-full" />
            <div>
              <div className="text-white font-semibold">{token.symbol}</div>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">${token.price.toFixed(2)}</span>
                <span className={token.change >= 0 ? "text-green-500" : "text-red-500"}>
                  {token.change >= 0 ? "+" : ""}
                  {token.change.toFixed(2)}%
                </span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-white">{token.balance}</div>
            <div className="text-gray-400">${(token.balance * token.price).toFixed(2)}</div>
          </div>
        </Link>
      ))}
    </div>
  )
}

