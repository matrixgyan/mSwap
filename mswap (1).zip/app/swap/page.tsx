"use client"

import { useState } from "react"
import { ArrowUpDown, Home, HelpCircle, FileText, User } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import BottomMenu from "@/components/bottom-menu"

export default function SwapPage() {
  const [fromToken, setFromToken] = useState({ symbol: "SOL", balance: "0" })
  const [toToken, setToToken] = useState({ symbol: "TON", balance: "0" })
  const [amount, setAmount] = useState("")
  const [activeInput, setActiveInput] = useState<"from" | "to">("from")
  const [swapRate, setSwapRate] = useState("47.00148450")
  const [updateTime, setUpdateTime] = useState(24)

  const handleNumberClick = (num: string) => {
    if (activeInput === "from") {
      setAmount((prev) => {
        if (num === "." && prev.includes(".")) return prev
        return prev + num
      })
    }
  }

  const handleDelete = () => {
    setAmount((prev) => prev.slice(0, -1))
  }

  const handlePercentage = (percent: number) => {
    // Calculate percentage of balance
    const maxAmount = Number.parseFloat(fromToken.balance)
    setAmount((maxAmount * (percent / 100)).toString())
  }

  return (
    <div className="flex flex-col h-screen bg-[#0a0f0a]">
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-[#1a3a1a]">
        <div className="flex gap-4">
          <div className="bg-[#4CAF50] text-white px-4 py-2 rounded-lg">Market Swap</div>
          <div className="text-gray-400 px-4 py-2">Limit Order</div>
        </div>
        <div className="flex gap-4">
          <HelpCircle className="w-6 h-6 text-gray-400" />
          <FileText className="w-6 h-6 text-gray-400" />
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 p-4 pb-20">
        {/* From Token Selection */}
        <div className="bg-[#0f1f0f] rounded-2xl p-6 mb-4">
          <div className="text-white text-xl mb-2">From</div>
          <button onClick={() => setActiveInput("from")} className="w-full flex justify-between items-center">
            <div className="flex items-center gap-2">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20250121_093137.jpg-k0JRbzxn5zkvZEALS6CaKN6f1zHEKI.jpeg"
                alt="SOL"
                className="w-8 h-8 rounded-full"
              />
              <span className="text-white text-2xl">{fromToken.symbol}</span>
            </div>
            <div className="text-white text-2xl">
              {activeInput === "from"
                ? amount || "0"
                : (Number.parseFloat(amount || "0") * Number.parseFloat(swapRate)).toFixed(8)}
            </div>
          </button>
        </div>

        {/* Swap Button */}
        <div className="relative flex justify-center -my-2 z-10">
          <button className="bg-[#1a3a1a] p-4 rounded-full">
            <ArrowUpDown className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* To Token Selection */}
        <div className="bg-[#0f1f0f] rounded-2xl p-6 mb-4">
          <div className="text-white text-xl mb-2">To</div>
          <button onClick={() => setActiveInput("to")} className="w-full flex justify-between items-center">
            <div className="flex items-center gap-2">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20250121_093137.jpg-k0JRbzxn5zkvZEALS6CaKN6f1zHEKI.jpeg"
                alt="TON"
                className="w-8 h-8 rounded-full"
              />
              <span className="text-white text-2xl">{toToken.symbol}</span>
            </div>
            <div className="text-white text-2xl">
              {activeInput === "to"
                ? amount || "0"
                : (Number.parseFloat(amount || "0") * Number.parseFloat(swapRate)).toFixed(8)}
            </div>
          </button>
        </div>

        {/* Rate Display */}
        <div className="flex justify-between items-center text-sm mb-4">
          <div className="text-white">
            1 {fromToken.symbol} ~ {swapRate} {toToken.symbol}
          </div>
          <div className="text-[#4CAF50]">Update in {updateTime}s</div>
        </div>

        {/* Balance and Percentage Selector */}
        <div className="mb-4">
          <div className="text-gray-400 mb-2">
            Balance: {fromToken.balance} {fromToken.symbol}
          </div>
          <div className="flex gap-4">
            <button onClick={() => handlePercentage(25)} className="text-[#4CAF50] text-lg">
              25%
            </button>
            <button onClick={() => handlePercentage(50)} className="text-[#4CAF50] text-lg">
              50%
            </button>
            <button onClick={() => handlePercentage(100)} className="text-[#4CAF50] text-lg">
              MAX
            </button>
          </div>
        </div>

        {/* Number Pad */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, ".", 0].map((num, index) => (
            <button
              key={num}
              onClick={() => handleNumberClick(num.toString())}
              className="text-white text-2xl h-14 rounded-lg flex items-center justify-center"
            >
              {num}
            </button>
          ))}
          <button
            onClick={handleDelete}
            className="text-white text-2xl h-14 rounded-lg flex items-center justify-center"
          >
            ⌫
          </button>
        </div>

        {/* Swap Button */}
        <button className="w-full bg-gray-800 text-white py-4 rounded-xl mb-4">Review and Swap</button>
        <BottomMenu />
      </main>

      {/* Bottom Navigation */}
      {/* This section is removed as BottomMenu component replaces it. */}
    </div>
  )
}

