"use client"

import { useState } from "react"
import { Eye, EyeOff, UserPlus } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import Link from "next/link"

const validEmailDomains = ["gmail.com", "hotmail.com", "yahoo.com", "outlook.com"]

export default function RegisterPage() {
  const [registrationType, setRegistrationType] = useState<"email" | "seedPhrase" | "privateKey">("email")
  const [email, setEmail] = useState("")
  const [seedPhrase, setSeedPhrase] = useState("")
  const [privateKey, setPrivateKey] = useState("")
  const [showSeedPhrase, setShowSeedPhrase] = useState(false)
  const [showPrivateKey, setShowPrivateKey] = useState(false)
  const [termsAccepted, setTermsAccepted] = useState(false)
  const [showTerms, setShowTerms] = useState(false)

  const validateEmail = (email: string) => {
    const domain = email.split("@")[1]
    return validEmailDomains.includes(domain)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!termsAccepted) {
      alert("Please accept the terms and conditions")
      return
    }
    // Handle registration logic here
    console.log("Registration submitted")
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2 animate-pulse">mSwap</h1>
          <p className="text-gray-400">Welcome to the future of decentralized finance</p>
        </div>

        <div className="bg-[#0f1f0f] rounded-2xl p-6 mb-4">
          <div className="flex justify-around mb-6">
            <button
              className={`px-4 py-2 rounded-full ${
                registrationType === "email" ? "bg-green-600 text-white" : "text-gray-400"
              }`}
              onClick={() => setRegistrationType("email")}
            >
              Email
            </button>
            <button
              className={`px-4 py-2 rounded-full ${
                registrationType === "seedPhrase" ? "bg-green-600 text-white" : "text-gray-400"
              }`}
              onClick={() => setRegistrationType("seedPhrase")}
            >
              Seed Phrase
            </button>
            <button
              className={`px-4 py-2 rounded-full ${
                registrationType === "privateKey" ? "bg-green-600 text-white" : "text-gray-400"
              }`}
              onClick={() => setRegistrationType("privateKey")}
            >
              Private Key
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {registrationType === "email" && (
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-1">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
                  placeholder="Enter your email"
                  required
                />
                {email && !validateEmail(email) && (
                  <p className="text-red-500 text-sm mt-1">
                    Please use a valid email from Gmail, Hotmail, Yahoo, or Outlook
                  </p>
                )}
              </div>
            )}

            {registrationType === "seedPhrase" && (
              <div>
                <label htmlFor="seedPhrase" className="block text-sm font-medium text-gray-400 mb-1">
                  Seed Phrase
                </label>
                <div className="relative">
                  <Input
                    id="seedPhrase"
                    type={showSeedPhrase ? "text" : "password"}
                    value={seedPhrase}
                    onChange={(e) => setSeedPhrase(e.target.value)}
                    className="bg-[#1a3a1a] border-[#2a4a2a] text-white pr-10"
                    placeholder="Enter your seed phrase"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowSeedPhrase(!showSeedPhrase)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400"
                  >
                    {showSeedPhrase ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>
            )}

            {registrationType === "privateKey" && (
              <div>
                <label htmlFor="privateKey" className="block text-sm font-medium text-gray-400 mb-1">
                  Private Key
                </label>
                <div className="relative">
                  <Input
                    id="privateKey"
                    type={showPrivateKey ? "text" : "password"}
                    value={privateKey}
                    onChange={(e) => setPrivateKey(e.target.value)}
                    className="bg-[#1a3a1a] border-[#2a4a2a] text-white pr-10"
                    placeholder="Enter your private key"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPrivateKey(!showPrivateKey)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400"
                  >
                    {showPrivateKey ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>
            )}

            <div className="flex items-center space-x-2">
              <Checkbox id="terms" checked={termsAccepted} onCheckedChange={() => setTermsAccepted(!termsAccepted)} />
              <label
                htmlFor="terms"
                className="text-sm text-gray-400 cursor-pointer"
                onClick={() => setShowTerms(true)}
              >
                I agree to the terms and conditions
              </label>
            </div>

            <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
              <UserPlus className="w-4 h-4 mr-2" />
              Register
            </Button>
          </form>
        </div>

        <p className="text-center text-gray-400 text-sm">
          &copy; 2023 mSwap. All rights reserved. Powered by MatrixGyan
        </p>
      </div>

      <Dialog open={showTerms} onOpenChange={setShowTerms}>
        <DialogContent className="bg-[#0f1f0f] text-white border-[#1a3a1a]">
          <DialogHeader>
            <DialogTitle>Terms and Conditions</DialogTitle>
          </DialogHeader>
          <div className="mt-4 text-sm text-gray-400">
            <p>Welcome to mSwap! By using our platform, you agree to the following terms and conditions:</p>
            <ul className="list-disc pl-5 mt-2 space-y-2">
              <li>You must be at least 18 years old to use mSwap.</li>
              <li>You are responsible for maintaining the security of your account and private keys.</li>
              <li>mSwap is not responsible for any loss of funds due to user error or hacking attempts.</li>
              <li>We reserve the right to modify or discontinue the service at any time.</li>
              <li>You agree to use mSwap in compliance with all applicable laws and regulations.</li>
              <li>mSwap collects and uses personal data as described in our Privacy Policy.</li>
            </ul>
            <p className="mt-4">
              By accepting these terms, you acknowledge that you have read, understood, and agree to be bound by them.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

