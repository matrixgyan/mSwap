"use client"

import { createContext, useContext, useState, useEffect } from "react"
import { toast } from "@/components/ui/use-toast"

interface AppContextType {
  language: string
  currency: string
  testnetMode: boolean
  isLoading: boolean
  setLanguage: (lang: string) => void
  setCurrency: (curr: string) => void
  setTestnetMode: (mode: boolean) => void
  setIsLoading: (loading: boolean) => void
}

const AppContext = createContext<AppContextType>({
  language: "en",
  currency: "USD",
  testnetMode: false,
  isLoading: false,
  setLanguage: () => {},
  setCurrency: () => {},
  setTestnetMode: () => {},
  setIsLoading: () => {},
})

export const useAppContext = () => useContext(AppContext)

export function AppProvider({ children }: { children: React.ReactNode }) {
  console.log("AppProvider rendering")
  const [language, setLanguage] = useState("en")
  const [currency, setCurrency] = useState("USD")
  const [testnetMode, setTestnetMode] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    console.log("AppProvider useEffect running")
    const savedLanguage = localStorage.getItem("language")
    const savedCurrency = localStorage.getItem("currency")
    const savedTestnetMode = localStorage.getItem("testnetMode")

    if (savedLanguage) setLanguage(savedLanguage)
    if (savedCurrency) setCurrency(savedCurrency)
    if (savedTestnetMode) setTestnetMode(savedTestnetMode === "true")
  }, [])

  const updateLanguage = (lang: string) => {
    setLanguage(lang)
    localStorage.setItem("language", lang)
    toast({
      title: "Language Updated",
      description: `The app language has been changed to ${lang}.`,
    })
  }

  const updateCurrency = (curr: string) => {
    setCurrency(curr)
    localStorage.setItem("currency", curr)
    toast({
      title: "Currency Updated",
      description: `The app currency has been changed to ${curr}.`,
    })
  }

  const updateTestnetMode = (mode: boolean) => {
    setTestnetMode(mode)
    localStorage.setItem("testnetMode", mode.toString())
    toast({
      title: "Testnet Mode Updated",
      description: `Testnet mode has been ${mode ? "enabled" : "disabled"}.`,
    })
    window.dispatchEvent(new Event("testnetModeChanged"))
  }

  return (
    <AppContext.Provider
      value={{
        language,
        currency,
        testnetMode,
        isLoading,
        setLanguage: updateLanguage,
        setCurrency: updateCurrency,
        setTestnetMode: updateTestnetMode,
        setIsLoading,
      }}
    >
      {console.log("AppProvider rendering children")}
      {children}
    </AppContext.Provider>
  )
}

