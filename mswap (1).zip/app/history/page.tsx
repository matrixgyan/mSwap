"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, RefreshCcw } from "lucide-react"
import { Card } from "@/components/ui/card"
import { getTransactionHistory } from "@/lib/api"
import Link from "next/link"
import BottomMenu from "@/components/bottom-menu"

interface Transaction {
  id: string
  type: string
  amount: number
  token: string
  date: string
  amountUsd: string
}

export default function HistoryPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchTransactions = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const history = await getTransactionHistory()
      setTransactions(history)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchTransactions()
  }, []) //This is the line that was flagged as needing a dependency, but it doesn't need one in this case because it only needs to run once on mount.  Adding a dependency would cause an infinite loop.

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-[#0a0f0a] border-b border-[#1a3a1a]">
        <div className="flex items-center gap-4">
          <Link href="/">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Transaction History</h1>
        </div>
        <button onClick={fetchTransactions} className="text-gray-400">
          <RefreshCcw className="w-6 h-6" />
        </button>
      </header>

      <main className="pt-16 pb-20 px-4">
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500"></div>
          </div>
        ) : error ? (
          <div className="bg-red-500/10 border border-red-500 rounded-lg p-4 mb-4">
            <p className="text-red-500">{error}</p>
            <button
              onClick={fetchTransactions}
              className="mt-2 px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors"
            >
              Try Again
            </button>
          </div>
        ) : transactions.length === 0 ? (
          <p className="text-center text-gray-400">No transactions found.</p>
        ) : (
          transactions.map((tx) => (
            <Card key={tx.id} className="bg-[#0f1f0f] border-[#1a3a1a] rounded-2xl p-4 mb-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-white font-semibold">{tx.type}</p>
                  <p className="text-sm text-gray-400">{tx.date}</p>
                </div>
                <div className="text-right">
                  <p className={`font-semibold ${tx.amount > 0 ? "text-green-500" : "text-red-500"}`}>
                    {tx.amount > 0 ? "+" : ""}
                    {tx.amount} {tx.token}
                  </p>
                  <p className="text-sm text-gray-400">${tx.amountUsd}</p>
                </div>
              </div>
            </Card>
          ))
        )}
      </main>

      <div className="fixed bottom-0 left-0 right-0 z-10 bg-[#0a0f0a] border-t border-[#1a3a1a]">
        <BottomMenu />
      </div>
    </div>
  )
}

