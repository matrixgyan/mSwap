"use client"

import { useState, useEffect } from "react"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useAppContext } from "../providers"
import { getTransactionHistory } from "@/lib/api"
import { toast } from "@/components/ui/use-toast"

interface Transaction {
  id: string
  type: string
  amount: string
  token: string
  date: string
  status: string
  txHash: string
}

export default function TransactionHistoryPage() {
  const { testnetMode } = useAppContext()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchTransactionHistory()
  }, [])

  const fetchTransactionHistory = async () => {
    setIsLoading(true)
    try {
      const history = await getTransactionHistory()
      setTransactions(history)
    } catch (error) {
      console.error("Failed to fetch transaction history:", error)
      toast.error("Failed to load transaction history. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white p-4">
      <header className="flex items-center mb-6">
        <Link href="/" className="mr-4">
          <ArrowLeft className="w-6 h-6" />
        </Link>
        <h1 className="text-2xl font-bold">Transaction History</h1>
      </header>

      {testnetMode && (
        <div className="bg-yellow-500 text-black p-4 rounded-lg mb-4">
          <h2 className="text-lg font-bold">Testnet Mode Active</h2>
          <p>You are viewing testnet transaction history.</p>
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500"></div>
        </div>
      ) : transactions.length > 0 ? (
        <div className="space-y-4">
          {transactions.map((tx) => (
            <div key={tx.id} className="bg-[#1a3a1a] p-4 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span className="font-semibold">{tx.type}</span>
                <span className={tx.status === "Confirmed" ? "text-green-500" : "text-yellow-500"}>{tx.status}</span>
              </div>
              <div className="text-sm text-gray-300 mb-2">{tx.date}</div>
              <div className="flex justify-between items-center">
                <span>
                  {tx.amount} {tx.token}
                </span>
                <a
                  href={`https://explorer.solana.com/tx/${tx.txHash}?cluster=devnet`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:underline"
                >
                  View on Explorer
                </a>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center text-gray-400 py-8">No transactions found.</div>
      )}
    </div>
  )
}

