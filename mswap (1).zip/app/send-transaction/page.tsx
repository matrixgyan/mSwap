"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useAppContext } from "../providers"
import { sendTestnetTransaction } from "@/lib/api"
import { toast } from "@/components/ui/use-toast"
import Link from "next/link"

export default function SendTransactionPage() {
  const router = useRouter()
  const { testnetMode } = useAppContext()
  const [recipient, setRecipient] = useState("")
  const [amount, setAmount] = useState("")
  const [tokenId, setTokenId] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showConfirmation, setShowConfirmation] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (validateInputs()) {
      setShowConfirmation(true)
    }
  }

  const validateInputs = () => {
    if (!recipient) {
      toast.error("Please enter a recipient address")
      return false
    }
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      toast.error("Please enter a valid amount")
      return false
    }
    if (!tokenId) {
      toast.error("Please select a token")
      return false
    }
    return true
  }

  const handleConfirmTransaction = async () => {
    setIsLoading(true)
    try {
      const result = await sendTestnetTransaction(tokenId, recipient, amount)
      if (result.success) {
        toast.success(`Transaction sent successfully. Hash: ${result.txHash}`)
        router.push("/transaction-history")
      } else {
        toast.error(`Failed to send transaction: ${result.message}`)
      }
    } catch (error) {
      console.error("Transaction error:", error)
      toast.error("Failed to send transaction. Please try again.")
    } finally {
      setIsLoading(false)
      setShowConfirmation(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white p-4">
      <header className="flex items-center mb-6">
        <Link href="/" className="mr-4">
          <ArrowLeft className="w-6 h-6" />
        </Link>
        <h1 className="text-2xl font-bold">Send Transaction</h1>
      </header>

      {testnetMode && (
        <div className="bg-yellow-500 text-black p-4 rounded-lg mb-4">
          <h2 className="text-lg font-bold">Testnet Mode Active</h2>
          <p>You are currently in testnet mode. All transactions are simulated.</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="recipient" className="block text-sm font-medium text-gray-400 mb-1">
            Recipient Address
          </label>
          <Input
            id="recipient"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            placeholder="Enter recipient address"
            className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
            required
          />
        </div>

        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-gray-400 mb-1">
            Amount
          </label>
          <Input
            id="amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Enter amount"
            className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
            required
            min="0"
            step="any"
          />
        </div>

        <div>
          <label htmlFor="tokenId" className="block text-sm font-medium text-gray-400 mb-1">
            Token
          </label>
          <select
            id="tokenId"
            value={tokenId}
            onChange={(e) => setTokenId(e.target.value)}
            className="w-full bg-[#1a3a1a] border-[#2a4a2a] text-white rounded-md p-2"
            required
          >
            <option value="">Select a token</option>
            <option value="SOL_DEVNET">Solana (Devnet)</option>
            <option value="ETH_GOERLI">Ethereum (Goerli)</option>
            <option value="BSC_TESTNET">BNB (Testnet)</option>
            <option value="MATIC_MUMBAI">Polygon (Mumbai)</option>
          </select>
        </div>

        <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isLoading}>
          {isLoading ? "Sending..." : "Send Transaction"}
        </Button>
      </form>

      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-[#0f1f0f] rounded-lg p-6 max-w-md w-full">
            <h2 className="text-xl font-bold mb-4">Confirm Transaction</h2>
            <p>
              Are you sure you want to send {amount} {tokenId.split("_")[0]} to {recipient}?
            </p>
            <div className="flex justify-end mt-6 space-x-4">
              <Button onClick={() => setShowConfirmation(false)} variant="outline">
                Cancel
              </Button>
              <Button onClick={handleConfirmTransaction} className="bg-green-600 hover:bg-green-700">
                Confirm
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

