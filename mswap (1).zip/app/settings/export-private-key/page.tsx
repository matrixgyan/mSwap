"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Copy, QrCode } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { QRCodeSVG } from "qrcode.react"

const networks = [
  { id: "ETH", name: "Ethereum", color: "#627EEA" },
  { id: "SOL", name: "Solana", color: "#00FFA3" },
  { id: "BTC", name: "Bitcoin", color: "#F7931A" },
  { id: "TRX", name: "Tron", color: "#FF0013" },
  { id: "MATIC", name: "Polygon", color: "#8247E5" },
  { id: "ARB", name: "Arbitrum", color: "#28A0F0" },
  { id: "BNB", name: "Binance Smart Chain", color: "#F3BA2F" },
  { id: "ADA", name: "Cardano", color: "#0033AD" },
  { id: "DOT", name: "Polkadot", color: "#E6007A" },
  { id: "AVAX", name: "Avalanche", color: "#E84142" },
]

export default function ExportPrivateKeyPage() {
  const [selectedNetwork, setSelectedNetwork] = useState("")
  const [privateKey, setPrivateKey] = useState("")
  const [showQR, setShowQR] = useState(false)

  useEffect(() => {
    // Load the last selected network from localStorage
    const lastNetwork = localStorage.getItem("lastSelectedNetwork")
    if (lastNetwork) {
      setSelectedNetwork(lastNetwork)
      generatePrivateKey(lastNetwork)
    }
  }, [])

  const generatePrivateKey = (networkId: string) => {
    // In a real-world scenario, you'd use a proper key derivation function
    // This is just a placeholder implementation
    const randomBytes = new Uint8Array(32)
    crypto.getRandomValues(randomBytes)
    return `${networkId}_${Array.from(randomBytes, (byte) => byte.toString(16).padStart(2, "0")).join("")}`
  }

  const handleNetworkChange = (networkId: string) => {
    setSelectedNetwork(networkId)
    const newPrivateKey = generatePrivateKey(networkId)
    setPrivateKey(newPrivateKey)
    localStorage.setItem("lastSelectedNetwork", networkId)
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(privateKey)
    alert("Private key copied to clipboard!")
  }

  const toggleQR = () => {
    setShowQR(!showQR)
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-[#0a0f0a] border-b border-[#1a3a1a]">
        <div className="flex items-center gap-4">
          <Link href="/settings">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Export Private Key</h1>
        </div>
      </header>

      <main className="pt-20 px-4 pb-20">
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-400 mb-2">Select Network</label>
          <Select value={selectedNetwork} onValueChange={handleNetworkChange}>
            <SelectTrigger className="w-full bg-[#1a3a1a] border-[#2a4a2a] text-white">
              <SelectValue placeholder="Choose a network" />
            </SelectTrigger>
            <SelectContent className="bg-[#1a3a1a] border-[#2a4a2a]">
              {networks.map((network) => (
                <SelectItem key={network.id} value={network.id} className="text-white hover:bg-[#2a4a2a]">
                  <div className="flex items-center">
                    <div className="w-4 h-4 rounded-full mr-2" style={{ backgroundColor: network.color }} />
                    {network.name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {privateKey && (
          <div className="bg-[#1a3a1a] p-6 rounded-lg mb-6">
            <p className="text-sm text-gray-400 mb-2">Private Key:</p>
            <p className="text-lg font-medium break-all mb-4">{privateKey}</p>
            <div className="flex gap-2">
              <Button onClick={handleCopy} className="flex-1 bg-blue-600 hover:bg-blue-700">
                <Copy className="w-4 h-4 mr-2" />
                Copy
              </Button>
              <Button onClick={toggleQR} className="flex-1 bg-green-600 hover:bg-green-700">
                <QrCode className="w-4 h-4 mr-2" />
                {showQR ? "Hide QR" : "Show QR"}
              </Button>
            </div>
          </div>
        )}

        {showQR && privateKey && (
          <div className="bg-white p-4 rounded-lg mb-6 flex justify-center">
            <QRCodeSVG value={privateKey} size={200} level="H" />
          </div>
        )}

        <p className="text-sm text-gray-400 mt-4">
          Warning: Never share your private key with anyone. It provides full access to your funds on the selected
          network.
        </p>
      </main>
    </div>
  )
}

