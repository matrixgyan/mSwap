"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Eye, EyeOff, Copy, RefreshCw } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

const generateSeedPhrase = () => {
  // This is a simplified version. In a real-world scenario, you'd use a proper library
  // like 'bip39' to generate a cryptographically secure seed phrase
  const words = [
    "apple",
    "banana",
    "cherry",
    "date",
    "elderberry",
    "fig",
    "grape",
    "honeydew",
    "kiwi",
    "lemon",
    "mango",
    "nectarine",
    "orange",
    "papaya",
    "quince",
    "raspberry",
    "strawberry",
    "tangerine",
    "ugli",
    "vanilla",
    "watermelon",
    "xigua",
    "yuzu",
    "zucchini",
  ]
  return Array.from({ length: 12 }, () => words[Math.floor(Math.random() * words.length)]).join(" ")
}

export default function SeedPhrasePage() {
  const [showSeedPhrase, setShowSeedPhrase] = useState(false)
  const [seedPhrase, setSeedPhrase] = useState("")

  useEffect(() => {
    setSeedPhrase(generateSeedPhrase())
  }, [])

  const handleCopy = () => {
    navigator.clipboard.writeText(seedPhrase)
    alert("Seed phrase copied to clipboard!")
  }

  const handleRegenerate = () => {
    setSeedPhrase(generateSeedPhrase())
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-[#0a0f0a] border-b border-[#1a3a1a]">
        <div className="flex items-center gap-4">
          <Link href="/settings">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Seed Phrase</h1>
        </div>
      </header>

      <main className="pt-16 px-4">
        <div className="bg-[#1a3a1a] p-4 rounded-lg mb-4">
          <p className="text-sm text-gray-400 mb-2">Your 12-word seed phrase:</p>
          {showSeedPhrase ? (
            <p className="text-lg font-medium break-words">{seedPhrase}</p>
          ) : (
            <p className="text-lg font-medium">••••• ••••• ••••• ••••• ••••• •••••</p>
          )}
        </div>
        <div className="flex gap-2 mb-4">
          <Button onClick={() => setShowSeedPhrase(!showSeedPhrase)} className="flex-1 bg-green-600 hover:bg-green-700">
            {showSeedPhrase ? (
              <>
                <EyeOff className="w-4 h-4 mr-2" />
                Hide
              </>
            ) : (
              <>
                <Eye className="w-4 h-4 mr-2" />
                Show
              </>
            )}
          </Button>
          <Button onClick={handleCopy} className="flex-1 bg-blue-600 hover:bg-blue-700">
            <Copy className="w-4 h-4 mr-2" />
            Copy
          </Button>
          <Button onClick={handleRegenerate} className="flex-1 bg-purple-600 hover:bg-purple-700">
            <RefreshCw className="w-4 h-4 mr-2" />
            Regenerate
          </Button>
        </div>
        <p className="text-sm text-gray-400">
          Warning: Never share your seed phrase with anyone. Keep it in a safe place. Anyone with your seed phrase can
          access your wallet.
        </p>
      </main>
    </div>
  )
}

