"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Edit, Trash2 } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

interface CustomNetwork {
  id: string
  name: string
  rpcUrl: string
  chainId: string
  symbol: string
  explorerUrl?: string
}

export default function CustomNetworksPage() {
  const [customNetworks, setCustomNetworks] = useState<CustomNetwork[]>([])

  useEffect(() => {
    // Here you would fetch the custom networks from your storage
    // For this example, we'll use some dummy data
    setCustomNetworks([
      { id: "1", name: "My Custom Network", rpcUrl: "https://rpc.example.com", chainId: "1337", symbol: "MCN" },
      { id: "2", name: "Test Network", rpcUrl: "https://rpc.test.com", chainId: "42", symbol: "TST" },
    ])
  }, [])

  const handleEdit = (network: CustomNetwork) => {
    // Here you would implement the logic to edit the network
    console.log("Editing network:", network)
  }

  const handleDelete = (networkId: string) => {
    // Here you would implement the logic to delete the network
    setCustomNetworks((prev) => prev.filter((network) => network.id !== networkId))
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-[#0a0f0a] border-b border-[#1a3a1a]">
        <div className="flex items-center gap-4">
          <Link href="/settings">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Custom Networks</h1>
        </div>
      </header>

      <main className="pt-16 px-4 pb-20">
        {customNetworks.map((network) => (
          <div key={network.id} className="bg-[#1a3a1a] p-4 rounded-lg mb-4">
            <h2 className="text-lg font-semibold mb-2">{network.name}</h2>
            <p className="text-sm text-gray-400 mb-1">RPC URL: {network.rpcUrl}</p>
            <p className="text-sm text-gray-400 mb-1">Chain ID: {network.chainId}</p>
            <p className="text-sm text-gray-400 mb-4">Symbol: {network.symbol}</p>
            <div className="flex justify-end gap-2">
              <Button onClick={() => handleEdit(network)} className="bg-blue-600 hover:bg-blue-700">
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
              <Button onClick={() => handleDelete(network.id)} className="bg-red-600 hover:bg-red-700">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </Button>
            </div>
          </div>
        ))}
        <Link href="/settings/add-custom-network">
          <Button className="w-full bg-green-600 hover:bg-green-700">Add New Custom Network</Button>
        </Link>
      </main>
    </div>
  )
}

