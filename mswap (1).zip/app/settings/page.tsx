"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, ChevronRight, Globe, DollarSign, Lock, Key, Mail, Zap, Plus, Check, Beaker } from "lucide-react"
import Link from "next/link"
import { Switch } from "@/components/ui/switch"
import BottomMenu from "@/components/bottom-menu"
import { useAppContext } from "../providers"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"

const languages = [
  { code: "en", name: "English" },
  { code: "es", name: "Español" },
  { code: "fr", name: "Français" },
  { code: "de", name: "Deutsch" },
  { code: "ja", name: "日本語" },
  { code: "zh", name: "中文" },
  { code: "hi", name: "हिन्दी" },
  { code: "ar", name: "العربية" },
  { code: "pt", name: "Português" },
  { code: "ru", name: "Русский" },
  { code: "ko", name: "한국어" },
  { code: "it", name: "Italiano" },
  { code: "nl", name: "Nederlands" },
  { code: "pl", name: "Polski" },
  { code: "tr", name: "Türkçe" },
  { code: "vi", name: "Tiếng Việt" },
  { code: "th", name: "ไทย" },
  { code: "id", name: "Bahasa Indonesia" },
]

const currencies = [
  { code: "USD", name: "US Dollar", symbol: "$" },
  { code: "EUR", name: "Euro", symbol: "€" },
  { code: "GBP", name: "British Pound", symbol: "£" },
  { code: "JPY", name: "Japanese Yen", symbol: "¥" },
  { code: "CNY", name: "Chinese Yuan", symbol: "¥" },
  { code: "INR", name: "Indian Rupee", symbol: "₹" },
  { code: "AUD", name: "Australian Dollar", symbol: "A$" },
  { code: "CAD", name: "Canadian Dollar", symbol: "C$" },
  { code: "CHF", name: "Swiss Franc", symbol: "Fr" },
  { code: "HKD", name: "Hong Kong Dollar", symbol: "HK$" },
  { code: "SGD", name: "Singapore Dollar", symbol: "S$" },
  { code: "SEK", name: "Swedish Krona", symbol: "kr" },
  { code: "KRW", name: "South Korean Won", symbol: "₩" },
  { code: "NOK", name: "Norwegian Krone", symbol: "kr" },
  { code: "NZD", name: "New Zealand Dollar", symbol: "NZ$" },
  { code: "MXN", name: "Mexican Peso", symbol: "$" },
  { code: "BRL", name: "Brazilian Real", symbol: "R$" },
  { code: "RUB", name: "Russian Ruble", symbol: "₽" },
]

export default function SettingsPage() {
  const { language, setLanguage, currency, setCurrency } = useAppContext()
  const [testnetMode, setTestnetMode] = useState(false)
  const [showLanguageModal, setShowLanguageModal] = useState(false)
  const [showCurrencyModal, setShowCurrencyModal] = useState(false)

  useEffect(() => {
    const savedTestnetMode = localStorage.getItem("testnetMode")
    if (savedTestnetMode) setTestnetMode(savedTestnetMode === "true")
  }, [])

  const handleLanguageChange = (langCode: string) => {
    setLanguage(langCode)
    setShowLanguageModal(false)
  }

  const handleCurrencyChange = (currencyCode: string) => {
    setCurrency(currencyCode)
    setShowCurrencyModal(false)
  }

  const handleTestnetToggle = () => {
    const newTestnetMode = !testnetMode
    setTestnetMode(newTestnetMode)
    localStorage.setItem("testnetMode", newTestnetMode.toString())
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-[#0a0f0a] border-b border-[#1a3a1a]">
        <div className="flex items-center gap-4">
          <Link href="/">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Settings</h1>
        </div>
      </header>

      <main className="pt-16 pb-20">
        <section className="mb-6">
          <h2 className="text-lg font-semibold px-4 mb-2">General</h2>
          <div className="bg-[#0f1f0f] border-t border-b border-[#1a3a1a]">
            <button
              onClick={() => setShowLanguageModal(true)}
              className="flex items-center justify-between w-full px-4 py-3 border-b border-[#1a3a1a]"
            >
              <div className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-gray-400" />
                <span>Language</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-400">{languages.find((lang) => lang.code === language)?.name}</span>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
            </button>
            <button
              onClick={() => setShowCurrencyModal(true)}
              className="flex items-center justify-between w-full px-4 py-3"
            >
              <div className="flex items-center gap-3">
                <DollarSign className="w-5 h-5 text-gray-400" />
                <span>Currency</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-400">{currencies.find((curr) => curr.code === currency)?.name}</span>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
            </button>
          </div>
        </section>

        <section className="mb-6">
          <h2 className="text-lg font-semibold px-4 mb-2">Security & Privacy</h2>
          <div className="bg-[#0f1f0f] border-t border-b border-[#1a3a1a]">
            <Link
              href="/settings/transaction-password"
              className="flex items-center justify-between w-full px-4 py-3 border-b border-[#1a3a1a]"
            >
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-gray-400" />
                <span>Transaction Password</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </Link>
            <Link
              href="/settings/seed-phrase"
              className="flex items-center justify-between w-full px-4 py-3 border-b border-[#1a3a1a]"
            >
              <div className="flex items-center gap-3">
                <Key className="w-5 h-5 text-gray-400" />
                <span>Seed Phrase</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </Link>
            <Link href="/settings/email-login" className="flex items-center justify-between w-full px-4 py-3">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-400" />
                <span>Email Login</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </Link>
          </div>
        </section>

        <section className="mb-6">
          <h2 className="text-lg font-semibold px-4 mb-2">Advanced</h2>
          <div className="bg-[#0f1f0f] border-t border-b border-[#1a3a1a]">
            <div className="flex items-center justify-between w-full px-4 py-3 border-b border-[#1a3a1a]">
              <div className="flex items-center gap-3">
                <Beaker className="w-5 h-5 text-gray-400" />
                <span>Testnet Mode</span>
              </div>
              <Switch checked={testnetMode} onCheckedChange={handleTestnetToggle} />
            </div>
            <Link
              href="/settings/add-custom-network"
              className="flex items-center justify-between w-full px-4 py-3 border-b border-[#1a3a1a]"
            >
              <div className="flex items-center gap-3">
                <Plus className="w-5 h-5 text-gray-400" />
                <span>Add Custom Network</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </Link>
            <Link href="/settings/export-private-key" className="flex items-center justify-between w-full px-4 py-3">
              <div className="flex items-center gap-3">
                <Key className="w-5 h-5 text-gray-400" />
                <span>Export Private Key</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </Link>
          </div>
        </section>

        <section>
          <h2 className="text-lg font-semibold px-4 mb-2">Networks</h2>
          <div className="bg-[#0f1f0f] border-t border-b border-[#1a3a1a]">
            <Link href="/settings/custom-networks" className="flex items-center justify-between w-full px-4 py-3">
              <span>Manage Custom Networks</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </Link>
          </div>
        </section>
      </main>

      <div className="fixed bottom-0 left-0 right-0 z-10 bg-[#0a0f0a] border-t border-[#1a3a1a]">
        <BottomMenu />
      </div>

      {/* Language Modal */}
      <Dialog open={showLanguageModal} onOpenChange={setShowLanguageModal}>
        <DialogContent className="bg-[#0f1f0f] text-white border-[#1a3a1a]">
          <DialogHeader>
            <DialogTitle>Select Language</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[400px] pr-4">
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => handleLanguageChange(lang.code)}
                className="flex items-center justify-between w-full py-2 px-4 hover:bg-[#1a3a1a] rounded-md"
              >
                <span>{lang.name}</span>
                {lang.code === language && <Check className="w-4 h-4 text-green-500" />}
              </button>
            ))}
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Currency Modal */}
      <Dialog open={showCurrencyModal} onOpenChange={setShowCurrencyModal}>
        <DialogContent className="bg-[#0f1f0f] text-white border-[#1a3a1a]">
          <DialogHeader>
            <DialogTitle>Select Currency</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[400px] pr-4">
            {currencies.map((curr) => (
              <button
                key={curr.code}
                onClick={() => handleCurrencyChange(curr.code)}
                className="flex items-center justify-between w-full py-2 px-4 hover:bg-[#1a3a1a] rounded-md"
              >
                <span>
                  {curr.name} ({curr.symbol})
                </span>
                {curr.code === currency && <Check className="w-4 h-4 text-green-500" />}
              </button>
            ))}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  )
}

