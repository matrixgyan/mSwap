"use client"

import { useState } from "react"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export default function EmailLoginPage() {
  const [email, setEmail] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would implement the logic to set up email login
    alert(`Email login set up for: ${email}`)
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-[#0a0f0a] border-b border-[#1a3a1a]">
        <div className="flex items-center gap-4">
          <Link href="/settings">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Email Login</h1>
        </div>
      </header>

      <main className="pt-16 px-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-1">
              Email Address
            </label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              placeholder="Enter your email address"
              required
            />
          </div>
          <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
            Set Up Email Login
          </Button>
        </form>
        <p className="mt-4 text-sm text-gray-400">
          Note: Setting up email login will allow you to access your wallet using your email address and a password.
          Make sure to use a strong, unique password.
        </p>
      </main>
    </div>
  )
}

