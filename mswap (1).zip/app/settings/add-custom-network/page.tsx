"use client"

import { useState } from "react"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export default function AddCustomNetworkPage() {
  const [networkInfo, setNetworkInfo] = useState({
    name: "",
    rpcUrl: "",
    chainId: "",
    symbol: "",
    explorerUrl: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would implement the logic to add the custom network
    console.log("Adding custom network:", networkInfo)
    alert("Custom network added successfully!")
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNetworkInfo((prev) => ({ ...prev, [name]: value }))
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-[#0a0f0a] border-b border-[#1a3a1a]">
        <div className="flex items-center gap-4">
          <Link href="/settings">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Add Custom Network</h1>
        </div>
      </header>

      <main className="pt-16 px-4 pb-20">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-1">
              Network Name
            </label>
            <Input
              id="name"
              name="name"
              value={networkInfo.name}
              onChange={handleChange}
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              placeholder="e.g. My Custom Network"
              required
            />
          </div>
          <div>
            <label htmlFor="rpcUrl" className="block text-sm font-medium text-gray-400 mb-1">
              RPC URL
            </label>
            <Input
              id="rpcUrl"
              name="rpcUrl"
              value={networkInfo.rpcUrl}
              onChange={handleChange}
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              placeholder="https://..."
              required
            />
          </div>
          <div>
            <label htmlFor="chainId" className="block text-sm font-medium text-gray-400 mb-1">
              Chain ID
            </label>
            <Input
              id="chainId"
              name="chainId"
              value={networkInfo.chainId}
              onChange={handleChange}
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              placeholder="e.g. 1"
              required
            />
          </div>
          <div>
            <label htmlFor="symbol" className="block text-sm font-medium text-gray-400 mb-1">
              Currency Symbol
            </label>
            <Input
              id="symbol"
              name="symbol"
              value={networkInfo.symbol}
              onChange={handleChange}
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              placeholder="e.g. ETH"
              required
            />
          </div>
          <div>
            <label htmlFor="explorerUrl" className="block text-sm font-medium text-gray-400 mb-1">
              Block Explorer URL (Optional)
            </label>
            <Input
              id="explorerUrl"
              name="explorerUrl"
              value={networkInfo.explorerUrl}
              onChange={handleChange}
              className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
              placeholder="https://..."
            />
          </div>
          <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
            Add Network
          </Button>
        </form>
      </main>
    </div>
  )
}

