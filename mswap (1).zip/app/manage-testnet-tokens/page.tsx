"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Plus, X } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import BottomMenu from "@/components/bottom-menu"
import { toast } from "sonner"
import { cn } from "@/lib/utils"

const defaultTestnetTokens = [
  {
    id: "SOL_DEVNET",
    symbol: "SOL",
    name: "Devnet Solana",
    network: "Testnet Networks",
    logo: "https://cryptologos.cc/logos/solana-sol-logo.png",
    enabled: true,
  },
  {
    id: "ETH_GOERLI",
    symbol: "ETH",
    name: "Goerli Ethereum",
    network: "Testnet Networks",
    logo: "https://cryptologos.cc/logos/ethereum-eth-logo.png",
    enabled: true,
  },
  {
    id: "BSC_TESTNET",
    symbol: "BNB",
    name: "BSC Testnet",
    network: "Testnet Networks",
    logo: "https://cryptologos.cc/logos/bnb-bnb-logo.png",
    enabled: true,
  },
  {
    id: "TON_TESTNET",
    symbol: "TON",
    name: "TON Testnet",
    network: "Testnet Networks",
    logo: "https://cryptologos.cc/logos/toncoin-ton-logo.png",
    enabled: true,
  },
  {
    id: "TRX_NILE",
    symbol: "TRX",
    name: "Tron Nile Testnet",
    network: "Testnet Networks",
    logo: "https://cryptologos.cc/logos/tron-trx-logo.png",
    enabled: true,
  },
  {
    id: "MATIC_MUMBAI",
    symbol: "MATIC",
    name: "Polygon Mumbai",
    network: "Testnet Networks",
    logo: "https://cryptologos.cc/logos/polygon-matic-logo.png",
    enabled: true,
  },
]

export default function ManageTestnetTokensPage() {
  const [tokens, setTokens] = useState(defaultTestnetTokens)
  const [showAddToken, setShowAddToken] = useState(false)
  const [newToken, setNewToken] = useState({
    id: "",
    symbol: "",
    name: "",
    network: "Testnet Networks",
  })
  const [isVerifying, setIsVerifying] = useState(false)

  useEffect(() => {
    const storedTokens = localStorage.getItem("testnetTokens")
    if (storedTokens) {
      setTokens(JSON.parse(storedTokens))
    } else {
      localStorage.setItem("testnetTokens", JSON.stringify(defaultTestnetTokens))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("testnetTokens", JSON.stringify(tokens))
  }, [tokens])

  const handleToggle = async (id: string) => {
    try {
      const updatedTokens = tokens.map((token) => (token.id === id ? { ...token, enabled: !token.enabled } : token))
      setTokens(updatedTokens)

      const toggledToken = updatedTokens.find((token) => token.id === id)
      if (toggledToken) {
        toast.success(
          toggledToken.enabled ? `${toggledToken.symbol} has been enabled` : `${toggledToken.symbol} has been disabled`,
        )
      }
    } catch (error) {
      toast.error("Failed to update token status. Please try again.")
    }
  }

  const handleAddToken = async () => {
    setIsVerifying(true)
    try {
      // Simulate token verification
      await new Promise((resolve) => setTimeout(resolve, 1500))

      const newTokenData = {
        ...newToken,
        enabled: true,
        logo: "/placeholder.svg",
      }

      setTokens((prevTokens) => {
        const updatedTokens = [...prevTokens, newTokenData]
        localStorage.setItem("testnetTokens", JSON.stringify(updatedTokens))
        return updatedTokens
      })
      setShowAddToken(false)
      setNewToken({ id: "", symbol: "", name: "", network: "Testnet Networks" })
      toast.success(`${newToken.symbol} has been added successfully`)
    } catch (error) {
      toast.error("Failed to add token. Please try again.")
    } finally {
      setIsVerifying(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white">
      <header className="flex items-center justify-between p-4 border-b border-[#1a3a1a]">
        <div className="flex items-center gap-4">
          <Link href="/">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Manage Testnet Tokens</h1>
        </div>
      </header>

      <main className="p-4 pb-20">
        <div className="space-y-4">
          {tokens.map((token) => (
            <div key={token.id} className="flex items-center justify-between p-4 bg-[#0f1f0f] rounded-xl">
              <div className="flex items-center gap-3">
                <img src={token.logo || "/placeholder.svg"} alt={token.name} className="w-8 h-8 rounded-full" />
                <div>
                  <h3 className="font-semibold">{token.name}</h3>
                  <p className="text-sm text-gray-400">{token.symbol}</p>
                </div>
              </div>
              <Switch
                checked={token.enabled}
                onCheckedChange={() => handleToggle(token.id)}
                className={cn("data-[state=checked]:bg-green-500", "data-[state=unchecked]:bg-red-500")}
              />
            </div>
          ))}
        </div>

        {/* Add Custom Token Button */}
        <button
          onClick={() => setShowAddToken(true)}
          className="flex items-center justify-center gap-2 w-full mt-6 p-4 bg-[#0f1f0f] text-white rounded-xl"
        >
          <Plus className="w-5 h-5" />
          <span>Add custom testnet token</span>
        </button>

        {/* Add Custom Token Modal */}
        {showAddToken && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-[#0f1f0f] rounded-2xl p-6 w-full max-w-md">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-medium">Add custom testnet token</h2>
                <button onClick={() => setShowAddToken(false)}>
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Token ID</label>
                  <Input
                    type="text"
                    value={newToken.id}
                    onChange={(e) => setNewToken({ ...newToken, id: e.target.value })}
                    placeholder="e.g. NEW_TESTNET"
                    className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-2">Token Symbol</label>
                  <Input
                    type="text"
                    value={newToken.symbol}
                    onChange={(e) => setNewToken({ ...newToken, symbol: e.target.value })}
                    placeholder="e.g. NEW"
                    className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-2">Token Name</label>
                  <Input
                    type="text"
                    value={newToken.name}
                    onChange={(e) => setNewToken({ ...newToken, name: e.target.value })}
                    placeholder="e.g. New Testnet Token"
                    className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
                  />
                </div>

                <button
                  onClick={handleAddToken}
                  disabled={isVerifying || !newToken.id || !newToken.symbol || !newToken.name}
                  className="w-full bg-[#4caf50] hover:bg-[#45a049] disabled:opacity-50 disabled:cursor-not-allowed text-white py-3 rounded-xl mt-4"
                >
                  {isVerifying ? "Verifying..." : "Add Token"}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      <BottomMenu />
    </div>
  )
}

