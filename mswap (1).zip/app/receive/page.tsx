"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, ChevronDown, Copy } from "lucide-react"
import { QRCodeSVG } from "qrcode.react"
import { cn } from "@/lib/utils"
import BottomMenu from "@/components/bottom-menu"
import { requestTestnetTokens } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"

export default function ReceivePage() {
  const [selectedNetwork, setSelectedNetwork] = useState("SOL")
  const [address, setAddress] = useState("")
  const [memo, setMemo] = useState("")
  const [showNetworkSelect, setShowNetworkSelect] = useState(false)
  const [copied, setCopied] = useState(false)
  const [testnetMode, setTestnetMode] = useState(false)
  const [testnetAddresses, setTestnetAddresses] = useState<{ [key: string]: string }>({})

  const networks = [
    { id: "SOL", name: "Solana", logo: "https://cryptologos.cc/logos/solana-sol-logo.png" },
    { id: "TON", name: "TON", logo: "https://cryptologos.cc/logos/toncoin-ton-logo.png" },
    { id: "ETH", name: "Ethereum", logo: "https://cryptologos.cc/logos/ethereum-eth-logo.png" },
    { id: "BTC", name: "Bitcoin", logo: "https://cryptologos.cc/logos/bitcoin-btc-logo.png" },
    { id: "BNB", name: "Binance Coin", logo: "https://cryptologos.cc/logos/bnb-bnb-logo.png" },
  ]

  useEffect(() => {
    // Load testnet mode from localStorage
    const savedTestnetMode = localStorage.getItem("testnetMode")
    if (savedTestnetMode) setTestnetMode(savedTestnetMode === "true")

    // Load testnet addresses from localStorage
    const savedTestnetAddresses = localStorage.getItem("testnetAddresses")
    if (savedTestnetAddresses) setTestnetAddresses(JSON.parse(savedTestnetAddresses))

    // Simulate fetching address for selected network
    const addresses = {
      SOL: "7YWHMfk9JZe0LM0g1ZauHuiSxhI9DtQxYdXhgyQSW",
      TON: "EQBfAN7LfaUYgXZNw5Wc7GbBMGiQhFOrlcGMSgIvHOTMQZKg",
      ETH: "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
      BTC: "3FZbgi29cpjq2GjdwV8eyHuJJnkLtktZc5",
      BNB: "bnb1jxfh2g85q3v0tdq56fnevx6xcxtcnhtsmcu64m",
    }
    setAddress(addresses[selectedNetwork] || "")
  }, [selectedNetwork])

  const handleCopy = async () => {
    const textToCopy = memo ? `${address}?memo=${memo}` : address
    await navigator.clipboard.writeText(textToCopy)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const getTestnetAddress = (networkId: string) => {
    switch (networkId) {
      case "SOL":
        return testnetAddresses["SOL_DEVNET"]
      case "ETH":
        return testnetAddresses["ETH_GOERLI"]
      case "BNB":
        return testnetAddresses["BSC_TESTNET"]
      case "TON":
        return testnetAddresses["TON_TESTNET"]
      default:
        return "Testnet address not available"
    }
  }

  const getTestnetInstructions = (networkId: string) => {
    switch (networkId) {
      case "SOL":
        return "Use the Solana Devnet faucet to receive testnet SOL: https://solfaucet.com/"
      case "ETH":
        return "Use the Goerli faucet to receive testnet ETH: https://goerlifaucet.com/"
      case "BNB":
        return "Use the BSC Testnet faucet to receive testnet BNB: https://testnet.binance.org/faucet-smart"
      case "TON":
        return "Use the TON Testnet faucet to receive testnet TON: https://faucet.tonhub.com/"
      default:
        return "Testnet faucet not available for this network"
    }
  }

  const handleRequestTestnetTokens = async () => {
    try {
      const result = await requestTestnetTokens(selectedNetwork, testnetAddresses[selectedNetwork])
      if (result.success) {
        toast.success(`Testnet ${selectedNetwork} tokens requested successfully`)
      } else {
        toast.error(`Failed to request testnet ${selectedNetwork} tokens: ${result.message}`)
      }
    } catch (error) {
      console.error("Failed to request testnet tokens:", error)
      toast.error("Failed to request testnet tokens. Please try again.")
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#0a0f0a]">
      {/* Header */}
      <header className="flex items-center gap-4 p-4 border-b border-[#1a3a1a]">
        <button onClick={() => window.history.back()} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold text-white">Receive</h1>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 pb-20">
        {testnetMode && (
          <div className="bg-yellow-500 text-black p-4 rounded-lg mb-4">
            <h2 className="text-lg font-bold">Testnet Mode Active</h2>
            <p>You are currently in testnet mode. All transactions are simulated.</p>
          </div>
        )}

        {/* Network Selection */}
        <div className="mb-6">
          <div className="text-gray-400 mb-2">Network</div>
          <div className="relative">
            <button
              onClick={() => setShowNetworkSelect(!showNetworkSelect)}
              className="w-full flex items-center justify-between bg-[#0f1f0f] border border-[#1a3a1a] rounded-xl p-4"
            >
              <div className="flex items-center gap-3">
                <img
                  src={networks.find((n) => n.id === selectedNetwork)?.logo || "/placeholder.svg"}
                  alt={selectedNetwork}
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-white">{networks.find((n) => n.id === selectedNetwork)?.name}</span>
              </div>
              <ChevronDown
                className={cn(
                  "w-5 h-5 text-gray-400 transition-transform",
                  showNetworkSelect && "transform rotate-180",
                )}
              />
            </button>

            {showNetworkSelect && (
              <div className="absolute w-full mt-2 bg-[#0f1f0f] border border-[#1a3a1a] rounded-xl overflow-hidden z-50">
                {networks.map((network) => (
                  <button
                    key={network.id}
                    onClick={() => {
                      setSelectedNetwork(network.id)
                      setShowNetworkSelect(false)
                    }}
                    className="w-full flex items-center gap-3 p-4 hover:bg-[#1a3a1a] transition-colors"
                  >
                    <img src={network.logo || "/placeholder.svg"} alt={network.name} className="w-8 h-8 rounded-full" />
                    <span className="text-white">{network.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* QR Code and Address Card */}
        <div className="bg-[#0f1f0f] border border-[#1a3a1a] rounded-2xl p-6 mb-6">
          <div className="flex justify-center mb-6">
            <div className="bg-white p-4 rounded-xl">
              <QRCodeSVG
                value={testnetMode ? getTestnetAddress(selectedNetwork) : memo ? `${address}?memo=${memo}` : address}
                size={200}
                level="H"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="text-gray-400 mb-2">Address</div>
              <div className="flex items-center gap-2 bg-[#1a3a1a] rounded-xl p-4">
                <div className="flex-1 text-white break-all">
                  {testnetMode ? getTestnetAddress(selectedNetwork) : address}
                </div>
                <button onClick={handleCopy} className="flex items-center gap-2 text-[#4caf50]">
                  <Copy className="w-5 h-5" />
                  {copied ? "Copied!" : "Copy"}
                </button>
              </div>
            </div>

            {selectedNetwork === "TON" && !testnetMode && (
              <div>
                <div className="text-gray-400 mb-2">Memo (Optional)</div>
                <input
                  type="text"
                  value={memo}
                  onChange={(e) => setMemo(e.target.value)}
                  placeholder="Enter memo"
                  className="w-full bg-[#1a3a1a] border border-[#2a4a2a] rounded-xl p-4 text-white placeholder-gray-400"
                />
              </div>
            )}
          </div>
        </div>

        {testnetMode && (
          <Button onClick={handleRequestTestnetTokens} className="w-full mt-4 bg-green-600 hover:bg-green-700">
            Request Testnet Tokens
          </Button>
        )}

        {/* Information Card */}
        <div className="bg-[#0f1f0f] border border-[#1a3a1a] rounded-2xl p-4">
          <div className="flex items-start gap-4">
            <div className="bg-[#1a3a1a] p-2 rounded-lg mt-1">
              <svg viewBox="0 0 24 24" className="w-6 h-6 text-white fill-current">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" />
              </svg>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-1">
                {testnetMode ? "Testnet Mode Active" : `Only send ${selectedNetwork} to this address`}
              </h3>
              <p className="text-gray-400">
                {testnetMode
                  ? getTestnetInstructions(selectedNetwork)
                  : "Sending any other assets may result in permanent loss"}
              </p>
            </div>
          </div>
        </div>
      </main>

      <BottomMenu />
    </div>
  )
}

