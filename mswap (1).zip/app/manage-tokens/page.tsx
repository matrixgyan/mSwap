"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Plus, X } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import BottomMenu from "@/components/bottom-menu"
import { toast } from "sonner"
import { cn } from "@/lib/utils"

const defaultTokens = [
  {
    id: "BTC",
    name: "Bitcoin",
    symbol: "BTC",
    enabled: true,
    logo: "https://cryptologos.cc/logos/bitcoin-btc-logo.png",
    network: "Layer 1 Networks",
    balance: "0.5",
    price: "$30,000",
    change: 2.5,
    balanceUsd: "$15,000",
  },
  {
    id: "ETH",
    name: "Ethereum",
    symbol: "ETH",
    enabled: true,
    logo: "https://cryptologos.cc/logos/ethereum-eth-logo.png",
    network: "Layer 1 Networks",
    balance: "2.0",
    price: "$2,000",
    change: -1.2,
    balanceUsd: "$4,000",
  },
  {
    id: "SOL",
    name: "Solana",
    symbol: "SOL",
    enabled: true,
    logo: "https://cryptologos.cc/logos/solana-sol-logo.png",
    network: "Layer 1 Networks",
    balance: "10.0",
    price: "$20",
    change: 5.7,
    balanceUsd: "$200",
  },
  {
    id: "TON",
    name: "Toncoin",
    symbol: "TON",
    enabled: true,
    logo: "https://cryptologos.cc/logos/toncoin-ton-logo.png",
    network: "Layer 1 Networks",
    balance: "100.0",
    price: "$2",
    change: 3.5,
    balanceUsd: "$200",
  },
  {
    id: "BNB",
    name: "Binance Coin",
    symbol: "BNB",
    enabled: true,
    logo: "https://cryptologos.cc/logos/bnb-bnb-logo.png",
    network: "Layer 1 Networks",
    balance: "5.0",
    price: "$300",
    change: 1.5,
    balanceUsd: "$1,500",
  },
  {
    id: "MATIC",
    name: "Polygon",
    symbol: "MATIC",
    enabled: true,
    logo: "https://cryptologos.cc/logos/polygon-matic-logo.png",
    network: "Layer 2 Networks",
    balance: "100.0",
    price: "$1",
    change: 3.2,
    balanceUsd: "$100",
  },
  {
    id: "ARB",
    name: "Arbitrum",
    symbol: "ARB",
    enabled: true,
    logo: "https://cryptologos.cc/logos/arbitrum-arb-logo.png",
    network: "Layer 2 Networks",
    balance: "50.0",
    price: "$1.20",
    change: 4.5,
    balanceUsd: "$60",
  },
  {
    id: "STARKNET",
    name: "StarkNet",
    symbol: "STRK",
    enabled: true,
    logo: "/placeholder.svg",
    network: "Layer 3 Networks",
    balance: "25.0",
    price: "$2.50",
    change: 1.8,
    balanceUsd: "$62.50",
  },
  {
    id: "UNI",
    name: "Uniswap",
    symbol: "UNI",
    enabled: true,
    logo: "https://cryptologos.cc/logos/uniswap-uni-logo.png",
    network: "DeFi Networks",
    balance: "15.0",
    price: "$5",
    change: 2.1,
    balanceUsd: "$75",
  },
  {
    id: "AAVE",
    name: "Aave",
    symbol: "AAVE",
    enabled: true,
    logo: "https://cryptologos.cc/logos/aave-aave-logo.png",
    network: "DeFi Networks",
    balance: "2.5",
    price: "$60",
    change: -0.8,
    balanceUsd: "$150",
  },
  {
    id: "DOT",
    name: "Polkadot",
    symbol: "DOT",
    enabled: true,
    logo: "https://cryptologos.cc/logos/polkadot-new-dot-logo.png",
    network: "Layer 1 Networks",
    balance: "100.0",
    price: "$5",
    change: 1.2,
    balanceUsd: "$500",
  },
  {
    id: "AVAX",
    name: "Avalanche",
    symbol: "AVAX",
    enabled: true,
    logo: "https://cryptologos.cc/logos/avalanche-avax-logo.png",
    network: "Layer 1 Networks",
    balance: "50.0",
    price: "$10",
    change: 2.5,
    balanceUsd: "$500",
  },
  {
    id: "ADA",
    name: "Cardano",
    symbol: "ADA",
    enabled: true,
    logo: "https://cryptologos.cc/logos/cardano-ada-logo.png",
    network: "Layer 1 Networks",
    balance: "1000.0",
    price: "$0.30",
    change: -0.8,
    balanceUsd: "$300",
  },
  {
    id: "OP",
    name: "Optimism",
    symbol: "OP",
    enabled: true,
    logo: "https://cryptologos.cc/logos/optimism-ethereum-op-logo.png",
    network: "Layer 2 Networks",
    balance: "200.0",
    price: "$1.50",
    change: 3.7,
    balanceUsd: "$300",
  },
  {
    id: "METIS",
    name: "Metis",
    symbol: "METIS",
    enabled: true,
    logo: "https://cryptologos.cc/logos/metis-metis-logo.png",
    network: "Layer 2 Networks",
    balance: "50.0",
    price: "$20",
    change: 5.2,
    balanceUsd: "$1000",
  },
  {
    id: "TRX",
    name: "Tron",
    symbol: "TRX",
    enabled: true,
    logo: "https://cryptologos.cc/logos/tron-trx-logo.png",
    network: "Layer 1 Networks",
    balance: "10000.0",
    price: "$0.08",
    change: 1.5,
    balanceUsd: "$800",
  },
]

export default function ManageTokensPage() {
  const [tokens, setTokens] = useState(defaultTokens)
  const [showAddToken, setShowAddToken] = useState(false)
  const [newToken, setNewToken] = useState({
    address: "",
    symbol: "",
    decimals: "",
    network: "Layer 1 Networks",
  })
  const [isVerifying, setIsVerifying] = useState(false)

  useEffect(() => {
    const storedTokens = localStorage.getItem("managedTokens")
    if (storedTokens) {
      setTokens(JSON.parse(storedTokens))
    } else {
      localStorage.setItem("managedTokens", JSON.stringify(defaultTokens))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("managedTokens", JSON.stringify(tokens))
  }, [tokens])

  const handleToggle = async (id: string) => {
    try {
      const updatedTokens = tokens.map((token) => (token.id === id ? { ...token, enabled: !token.enabled } : token))
      setTokens(updatedTokens)

      const toggledToken = updatedTokens.find((token) => token.id === id)
      if (toggledToken) {
        toast.success(
          toggledToken.enabled ? `${toggledToken.symbol} has been enabled` : `${toggledToken.symbol} has been disabled`,
        )
      }
    } catch (error) {
      toast.error("Failed to update token status. Please try again.")
    }
  }

  const validateTokenAddress = (address: string, network: string) => {
    // This is a simplified validation. In a real-world scenario, you'd want more robust validation.
    switch (network) {
      case "Layer 1 Networks":
        return address.startsWith("0x") && address.length === 42
      case "Layer 2 Networks":
      case "Layer 3 Networks":
        return address.length === 42 || address.length === 44
      case "DeFi Networks":
        return address.length > 0 // Simplified check for demonstration
      default:
        return false
    }
  }

  const handleAddToken = async () => {
    setIsVerifying(true)
    try {
      // Simulate token verification
      await new Promise((resolve) => setTimeout(resolve, 1500))

      if (!validateTokenAddress(newToken.address, newToken.network)) {
        toast.error("Invalid token address for the selected network. Please check and try again.")
        return
      }

      const newTokenData = {
        id: newToken.symbol,
        name: newToken.symbol,
        symbol: newToken.symbol,
        enabled: true,
        logo: "/placeholder.svg",
        network: newToken.network,
        balance: "0",
        price: "$0",
        change: 0,
        balanceUsd: "$0",
      }

      setTokens((prevTokens) => {
        const updatedTokens = [...prevTokens, newTokenData]
        localStorage.setItem("managedTokens", JSON.stringify(updatedTokens))
        return updatedTokens
      })
      setShowAddToken(false)
      setNewToken({ address: "", symbol: "", decimals: "", network: "Layer 1 Networks" })
      toast.success(`${newToken.symbol} has been added successfully`)
    } catch (error) {
      toast.error("Failed to add token. Please try again.")
    } finally {
      setIsVerifying(false)
    }
  }

  const handleAddCustomNetworkToken = (newNetwork) => {
    const newTokenData = {
      id: newNetwork.symbol,
      name: newNetwork.name,
      symbol: newNetwork.symbol,
      enabled: true,
      logo: "/placeholder.svg",
      network: newNetwork.networkType,
      balance: "0",
      price: "$0",
      change: 0,
      balanceUsd: "$0",
    }

    setTokens((prevTokens) => {
      const tokenExists = prevTokens.some((token) => token.symbol === newNetwork.symbol)
      if (!tokenExists) {
        const updatedTokens = [...prevTokens, newTokenData]
        localStorage.setItem("managedTokens", JSON.stringify(updatedTokens))
        return updatedTokens
      }
      return prevTokens
    })
    toast.success(`${newNetwork.name} (${newNetwork.symbol}) has been added to your tokens`)
  }

  useEffect(() => {
    const handleStorageChange = (e) => {
      if (e.key === "selectedNetwork") {
        const newNetwork = JSON.parse(e.newValue)
        if (newNetwork && newNetwork.symbol) {
          handleAddCustomNetworkToken(newNetwork)
        }
      }
    }

    window.addEventListener("storage", handleStorageChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
    }
  }, [])

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white">
      <header className="flex items-center justify-between p-4 border-b border-[#1a3a1a]">
        <div className="flex items-center gap-4">
          <Link href="/">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Manage tokens</h1>
        </div>
      </header>

      <main className="p-4 pb-20">
        {["Layer 1 Networks", "Layer 2 Networks", "Layer 3 Networks", "DeFi Networks"].map((network) => (
          <div key={network} className="mb-6">
            <h2 className="text-lg font-semibold mb-2">{network}</h2>
            <div className="space-y-4">
              {tokens
                .filter((token) => token.network === network)
                .map((token) => (
                  <div key={token.id} className="flex items-center justify-between p-4 bg-[#0f1f0f] rounded-xl">
                    <div className="flex items-center gap-3">
                      <img src={token.logo || "/placeholder.svg"} alt={token.name} className="w-8 h-8 rounded-full" />
                      <div>
                        <h3 className="font-semibold">{token.name}</h3>
                        <p className="text-sm text-gray-400">{token.symbol}</p>
                      </div>
                    </div>
                    <Switch
                      checked={token.enabled}
                      onCheckedChange={() => handleToggle(token.id)}
                      className={cn("data-[state=checked]:bg-green-500", "data-[state=unchecked]:bg-red-500")}
                    />
                  </div>
                ))}
            </div>
          </div>
        ))}

        {/* Add Custom Token Button */}
        <button
          onClick={() => setShowAddToken(true)}
          className="flex items-center justify-center gap-2 w-full mt-6 p-4 bg-[#0f1f0f] text-white rounded-xl"
        >
          <Plus className="w-5 h-5" />
          <span>Add custom token</span>
        </button>

        {/* Add Custom Token Modal */}
        {showAddToken && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-[#0f1f0f] rounded-2xl p-6 w-full max-w-md">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-medium">Add custom token</h2>
                <button onClick={() => setShowAddToken(false)}>
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Network</label>
                  <select
                    value={newToken.network}
                    onChange={(e) => setNewToken({ ...newToken, network: e.target.value })}
                    className="w-full bg-[#1a3a1a] border border-[#2a4a2a] rounded-xl p-3 text-white"
                  >
                    <option value="Layer 1 Networks">Layer 1 Networks</option>
                    <option value="Layer 2 Networks">Layer 2 Networks</option>
                    <option value="Layer 3 Networks">Layer 3 Networks</option>
                    <option value="DeFi Networks">DeFi Networks</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-2">Token Contract Address</label>
                  <Input
                    type="text"
                    value={newToken.address}
                    onChange={(e) => setNewToken({ ...newToken, address: e.target.value })}
                    placeholder="0x..."
                    className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-2">Token Symbol</label>
                  <Input
                    type="text"
                    value={newToken.symbol}
                    onChange={(e) => setNewToken({ ...newToken, symbol: e.target.value })}
                    placeholder="ETH"
                    className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-2">Token Decimals</label>
                  <Input
                    type="number"
                    value={newToken.decimals}
                    onChange={(e) => setNewToken({ ...newToken, decimals: e.target.value })}
                    placeholder="18"
                    className="bg-[#1a3a1a] border-[#2a4a2a] text-white"
                  />
                </div>

                <button
                  onClick={handleAddToken}
                  disabled={isVerifying || !newToken.address || !newToken.symbol || !newToken.decimals}
                  className="w-full bg-[#4caf50] hover:bg-[#45a049] disabled:opacity-50 disabled:cursor-not-allowed text-white py-3 rounded-xl mt-4"
                >
                  {isVerifying ? "Verifying..." : "Add Token"}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      <BottomMenu />
    </div>
  )
}

