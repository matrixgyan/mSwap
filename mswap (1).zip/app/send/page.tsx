"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, ChevronDown, Copy, QrCode, BookOpen, ArrowDownUp } from "lucide-react"
import { cn } from "@/lib/utils"
import BottomMenu from "@/components/bottom-menu"
import { useAppContext } from "../providers"
import { toast } from "sonner"
import { sendTestnetTransaction } from "@/lib/api"

export default function SendPage() {
  const { testnetMode } = useAppContext()
  const [amount, setAmount] = useState("")
  const [recipient, setRecipient] = useState("")
  const [showTokenSelect, setShowTokenSelect] = useState(false)
  const [showNetworkSelect, setShowNetworkSelect] = useState(false)
  const [includeFee, setIncludeFee] = useState(false)
  const [showAddressBook, setShowAddressBook] = useState(false)
  const [selectedToken, setSelectedToken] = useState({
    id: "SOL",
    name: "Solana",
    symbol: "SOL",
    logo: "https://cryptologos.cc/logos/solana-sol-logo.png",
  })
  const [selectedNetwork, setSelectedNetwork] = useState({
    id: "SOL",
    name: "Solana",
    logo: "https://cryptologos.cc/logos/solana-sol-logo.png",
  })

  const tokens = [
    {
      id: "SOL",
      name: "Solana",
      symbol: "SOL",
      logo: "https://cryptologos.cc/logos/solana-sol-logo.png",
      networks: ["SOL"],
    },
    {
      id: "ETH",
      name: "Ethereum",
      symbol: "ETH",
      logo: "https://cryptologos.cc/logos/ethereum-eth-logo.png",
      networks: ["ETH", "BSC"],
    },
    {
      id: "BTC",
      name: "Bitcoin",
      symbol: "BTC",
      logo: "https://cryptologos.cc/logos/bitcoin-btc-logo.png",
      networks: ["BTC"],
    },
    {
      id: "BNB",
      name: "Binance Coin",
      symbol: "BNB",
      logo: "https://cryptologos.cc/logos/bnb-bnb-logo.png",
      networks: ["BSC"],
    },
  ]

  const networks = [
    { id: "SOL", name: "Solana", logo: "https://cryptologos.cc/logos/solana-sol-logo.png" },
    { id: "ETH", name: "Ethereum", logo: "https://cryptologos.cc/logos/ethereum-eth-logo.png" },
    { id: "BTC", name: "Bitcoin", logo: "https://cryptologos.cc/logos/bitcoin-btc-logo.png" },
    { id: "BSC", name: "Binance Smart Chain", logo: "https://cryptologos.cc/logos/bnb-bnb-logo.png" },
  ]

  const gasFee = "0.00418155"
  const balance = "0"
  const usdRate = 237.84

  useEffect(() => {
    if (selectedToken) {
      const defaultNetwork = networks.find((n) => selectedToken.networks.includes(n.id))
      if (defaultNetwork) {
        setSelectedNetwork(defaultNetwork)
      }
    }
  }, [selectedToken])

  const handleSendAll = () => {
    setAmount(balance)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!amount || !recipient) {
      toast.error("Please enter both amount and recipient address")
      return
    }

    try {
      if (testnetMode) {
        const result = await sendTestnetTransaction(selectedNetwork, recipient, amount)
        if (result.success) {
          toast.success(`Testnet transaction sent successfully: ${result.txHash}`)
        } else {
          toast.error(`Failed to send testnet transaction: ${result.message}`)
        }
      } else {
        // Implement mainnet transaction logic here
        toast.error("Mainnet transactions are not implemented in this demo")
      }
    } catch (error) {
      console.error("Transaction error:", error)
      toast.error("Failed to send transaction. Please try again.")
    }
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="flex items-center gap-4 p-4">
        <button onClick={() => window.history.back()}>
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-2xl font-medium">Send</h1>
      </header>

      <main className="p-4 space-y-6">
        {testnetMode && (
          <div className="bg-yellow-500 text-black p-4 rounded-lg">
            <h2 className="text-lg font-bold">Testnet Mode Active</h2>
            <p>You are currently in testnet mode. All transactions are simulated.</p>
          </div>
        )}

        {/* Amount Section */}
        <div>
          <h2 className="text-2xl mb-4">Amount</h2>
          <div className="bg-[#0f1f0f] rounded-2xl p-6">
            <div className="flex justify-between items-center mb-4">
              <input
                type="text"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                className="bg-transparent text-3xl text-gray-400 outline-none w-full"
              />
              <button onClick={() => setShowTokenSelect(true)} className="flex items-center gap-2">
                <img src={selectedToken.logo || "/placeholder.svg"} alt={selectedToken.symbol} className="w-6 h-6" />
                <span className="text-xl">{selectedToken.symbol}</span>
                <ChevronDown className="w-5 h-5" />
              </button>
            </div>
            <div className="flex items-center gap-2 text-gray-400">
              <ArrowDownUp className="w-4 h-4" />
              <span>~${(Number.parseFloat(amount || "0") * usdRate).toFixed(2)} USD</span>
            </div>
          </div>
          <div className="flex justify-between items-center mt-2">
            <span className="text-gray-400">
              Balance: {balance} {selectedToken.symbol}
            </span>
            <button onClick={handleSendAll} className="text-[#4caf50] font-medium">
              SEND ALL
            </button>
          </div>
        </div>

        {/* Network Section */}
        <div>
          <h2 className="text-2xl mb-4">Transaction network</h2>
          <div className="relative">
            <button
              onClick={() => setShowNetworkSelect(!showNetworkSelect)}
              className="w-full flex items-center justify-between bg-[#0f1f0f] border border-red-500/20 rounded-2xl p-6"
            >
              <div className="flex items-center gap-3">
                <img src={selectedNetwork.logo || "/placeholder.svg"} alt={selectedNetwork.id} className="w-6 h-6" />
                <span>{selectedNetwork.name}</span>
              </div>
              <ChevronDown
                className={cn("w-5 h-5 transition-transform", showNetworkSelect && "transform rotate-180")}
              />
            </button>
            {showNetworkSelect && (
              <div className="absolute w-full mt-2 bg-[#0f1f0f] border border-[#1a3a1a] rounded-xl overflow-hidden z-10">
                {networks
                  .filter((n) => selectedToken.networks.includes(n.id))
                  .map((network) => (
                    <button
                      key={network.id}
                      onClick={() => {
                        setSelectedNetwork(network)
                        setShowNetworkSelect(false)
                      }}
                      className="w-full flex items-center gap-3 p-4 hover:bg-[#2a4a2a] transition-colors text-white"
                    >
                      <img
                        src={network.logo || "/placeholder.svg"}
                        alt={network.name}
                        className="w-6 h-6 rounded-full"
                      />
                      <span>{network.name}</span>
                    </button>
                  ))}
              </div>
            )}
          </div>
          <div className="flex justify-between items-center mt-2">
            <div className="text-red-400">
              Gas fee: {gasFee} {selectedToken.symbol}
            </div>
            <button onClick={() => setIncludeFee(!includeFee)} className="text-[#4caf50] font-medium">
              INCLUDE FEE
            </button>
          </div>
          <div className="text-red-400 mt-1">Insufficient balance to cover the gas fee</div>
        </div>

        {/* Recipient Section */}
        <div>
          <h2 className="text-2xl mb-4">To</h2>
          <div className="bg-[#0f1f0f] rounded-2xl p-4 flex items-center gap-4">
            <input
              type="text"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="Recipient wallet address"
              className="bg-transparent text-gray-400 outline-none flex-1"
            />
            <div className="flex items-center gap-4">
              <button>
                <Copy className="w-6 h-6 text-gray-400" />
              </button>
              <button onClick={() => setShowAddressBook(true)}>
                <BookOpen className="w-6 h-6 text-gray-400" />
              </button>
              <button>
                <QrCode className="w-6 h-6 text-gray-400" />
              </button>
            </div>
          </div>
        </div>

        {/* Send Button */}
        <button
          className="w-full bg-green-600 text-white py-4 rounded-full mt-8"
          disabled={!amount || !recipient}
          onClick={handleSubmit}
        >
          {testnetMode ? "Send Testnet Transaction" : "Send"}
        </button>
      </main>

      {/* Token Selection Modal */}
      {showTokenSelect && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-[#0f1f0f] rounded-2xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-medium">Select Token</h2>
              <button onClick={() => setShowTokenSelect(false)}>
                <ArrowLeft className="w-6 h-6" />
              </button>
            </div>
            <div className="space-y-4">
              {tokens.map((token) => (
                <button
                  key={token.id}
                  onClick={() => {
                    setSelectedToken(token)
                    setShowTokenSelect(false)
                  }}
                  className="w-full flex items-center justify-between p-4 hover:bg-[#2a4a2a] transition-colors rounded-xl"
                >
                  <div className="flex items-center gap-3">
                    <img src={token.logo || "/placeholder.svg"} alt={token.name} className="w-8 h-8 rounded-full" />
                    <span className="font-medium">{token.name}</span>
                  </div>
                  <span className="text-gray-400">{token.symbol}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Address Book Modal */}
      {showAddressBook && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-[#0f1f0f] rounded-2xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-medium">Address Book</h2>
              <button onClick={() => setShowAddressBook(false)}>
                <ArrowLeft className="w-6 h-6" />
              </button>
            </div>
            <div className="space-y-4">
              {/* Sample address book entries */}
              <div className="border-b border-gray-800 pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">John Doe</h3>
                    <p className="text-gray-400 text-sm">7YWH...QSW</p>
                  </div>
                  <button
                    onClick={() => {
                      setRecipient("7YWHMfk9JZe0LM0g1ZauHuiSxhI9DtQxYdXhgyQSW")
                      setShowAddressBook(false)
                    }}
                    className="text-[#4caf50]"
                  >
                    Select
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      <BottomMenu />
    </div>
  )
}

