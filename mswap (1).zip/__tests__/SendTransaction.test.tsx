import { render, fireEvent, waitFor } from "@testing-library/react"
import SendTransactionPage from "../app/send-transaction/page"
import { AppProvider } from "../app/providers"
import { toast } from "@/components/ui/use-toast"
import { jest } from "@jest/globals" // Import jest

jest.mock("next/navigation", () => ({
  useRouter() {
    return {
      push: jest.fn(),
    }
  },
}))

jest.mock("@/lib/api", () => ({
  sendTestnetTransaction: jest.fn(),
}))

jest.mock("@/components/ui/use-toast", () => ({
  toast: {
    error: jest.fn(),
    success: jest.fn(),
  },
}))

describe("SendTransactionPage", () => {
  it("renders correctly", () => {
    const { getByText, getByLabelText } = render(
      <AppProvider>
        <SendTransactionPage />
      </AppProvider>,
    )

    expect(getByText("Send Transaction")).toBeInTheDocument()
    expect(getByLabelText("Recipient Address")).toBeInTheDocument()
    expect(getByLabelText("Amount")).toBeInTheDocument()
    expect(getByLabelText("Token")).toBeInTheDocument()
  })

  it("shows error when form is submitted with empty fields", async () => {
    const { getByText } = render(
      <AppProvider>
        <SendTransactionPage />
      </AppProvider>,
    )

    fireEvent.click(getByText("Send Transaction"))

    await waitFor(() => {
      expect(toast.error).toHaveBeen.calledWith("Please enter a recipient address")
    })
  })

  it("shows confirmation modal when form is submitted with valid data", async () => {
    const { getByText, getByLabelText } = render(
      <AppProvider>
        <SendTransactionPage />
      </AppProvider>,
    )

    fireEvent.change(getByLabelText("Recipient Address"), {
      target: { value: "0x1234567890123456789012345678901234567890" },
    })
    fireEvent.change(getByLabelText("Amount"), { target: { value: "1" } })
    fireEvent.change(getByLabelText("Token"), { target: { value: "SOL_DEVNET" } })

    fireEvent.click(getByText("Send Transaction"))

    await waitFor(() => {
      expect(getByText("Confirm Transaction")).toBeInTheDocument()
    })
  })
})

