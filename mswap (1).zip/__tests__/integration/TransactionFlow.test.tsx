import { render, fireEvent, waitFor } from "@testing-library/react"
import { AppProvider } from "../../app/providers"
import Home from "../../app/page"
import { sendTestnetTransaction, getTransactionHistory } from "@/lib/api"

jest.mock("@/lib/api", () => ({
  sendTestnetTransaction: jest.fn(),
  getTransactionHistory: jest.fn(),
}))

describe("Transaction Flow", () => {
  it("completes a full transaction flow", async () => {
    // Mock API responses
    ;(sendTestnetTransaction as jest.Mock)
      .mockResolvedValue({ success: true, txHash: "mock-tx-hash" })(getTransactionHistory as jest.Mock)
      .mockResolvedValue([
        {
          id: "1",
          type: "Send",
          amount: "1",
          token: "SOL",
          date: "2023-05-01",
          status: "Confirmed",
          txHash: "mock-tx-hash",
        },
      ])

    // Render Home page
    const { getByText, getByLabelText } = render(
      <AppProvider>
        <Home />
      </AppProvider>,
    )

    // Navigate to Send Transaction page
    fireEvent.click(getByText("Send"))

    // Fill and submit the transaction form
    fireEvent.change(getByLabelText("Recipient Address"), {
      target: { value: "0x1234567890123456789012345678901234567890" },
    })
    fireEvent.change(getByLabelText("Amount"), { target: { value: "1" } })
    fireEvent.change(getByLabelText("Token"), { target: { value: "SOL_DEVNET" } })
    fireEvent.click(getByText("Send Transaction"))

    // Confirm the transaction
    await waitFor(() => {
      expect(getByText("Confirm Transaction")).toBeInTheDocument()
    })
    fireEvent.click(getByText("Confirm"))

    // Check if the transaction was sent successfully
    await waitFor(() => {
      expect(getByText("Transaction sent successfully")).toBeInTheDocument()
    })

    // Navigate to Transaction History page
    fireEvent.click(getByText("Transaction History"))

    // Check if the transaction appears in the history
    await waitFor(() => {
      expect(getByText("mock-tx-hash")).toBeInTheDocument()
    })
  })
})

